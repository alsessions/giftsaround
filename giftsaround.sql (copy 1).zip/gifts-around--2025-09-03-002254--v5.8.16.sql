-- MySQL dump 10.13  Distrib 8.0.40, for Linux (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_piwtmhuwzyhtyvnedeooppdexrnfpiduiihz` (`primaryOwnerId`),
  CONSTRAINT `fk_euozabfnofgwfjakqfdqxwfuvbrkxfpyrlku` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_piwtmhuwzyhtyvnedeooppdexrnfpiduiihz` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kdulixmkftzgvfpketvrlegszwighcjwfcar` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_nhklddwdkgojupkwjabrjqxkewakskmaebkw` (`dateRead`),
  KEY `fk_vkuxxtyyjjywckucdcthjoougnsdbtpcvaak` (`pluginId`),
  CONSTRAINT `fk_jdezeabdcwjfgwccazuexfuhuaacmyxlhzrs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vkuxxtyyjjywckucdcthjoougnsdbtpcvaak` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_oxswqoyvxtvxdamesmfizxdswpmtofuqatum` (`sessionId`,`volumeId`),
  KEY `idx_rtpchyrpwiieqnsnxllxyejenjplboalbbuz` (`volumeId`),
  CONSTRAINT `fk_jzxcoebpkmocdjmlwhetmenljthapsgalasp` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yfjgoqkthargfstxnvbnxcqcrhzvvfmmthks` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `mimeType` varchar(255) DEFAULT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ohbgpxqbierdlfgaatnrurqdtizvadnbezsa` (`filename`,`folderId`),
  KEY `idx_fgxrzaizheiufguhhndgmdrvukcybkrrwvfn` (`folderId`),
  KEY `idx_arfdpomllwegsrjhhlrtggpcihfyomxendnz` (`volumeId`),
  KEY `fk_enhpvhvdhudoeehytqajrradymbcxkajotyt` (`uploaderId`),
  CONSTRAINT `fk_enhpvhvdhudoeehytqajrradymbcxkajotyt` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_oadsiaqkkeherrphxekwioiupoidrushaepa` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oylrmckzaaihuurztpnjxmeycoebhghpzpxc` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_piyizikelfymzjrxyomjrkgdyftewifixndn` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_voyhsdqmykypfvagpdjkxwyufmsdkmkxejem` (`siteId`),
  CONSTRAINT `fk_aoitbwzxdokzjaqzpbrpexhfyuhgyodzmgml` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_voyhsdqmykypfvagpdjkxwyufmsdkmkxejem` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_odyzbxqwtmfqyhlukpwmhahvkwllxcisfgrv` (`userId`),
  CONSTRAINT `fk_odyzbxqwtmfqyhlukpwmhahvkwllxcisfgrv` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bulkopevents`
--

DROP TABLE IF EXISTS `bulkopevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bulkopevents` (
  `key` char(10) NOT NULL,
  `senderClass` varchar(255) NOT NULL,
  `eventName` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`key`,`senderClass`,`eventName`),
  KEY `idx_jtlazzifradcdyczthfloqbkjretczqjfgmw` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lbonnpugayyzqkishdawgrnqrdmydugxpxlo` (`groupId`),
  KEY `fk_sphfoihctsfdslvlmmmhjibomerqvzfzbafe` (`parentId`),
  CONSTRAINT `fk_opckbjpscyokhkmvxwlblfgsavndwottjfhe` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sphfoihctsfdslvlmmmhjibomerqvzfzbafe` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xagycngbyrbyqphikgevdpzocwuthphzqgfg` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dvekgyuwymtidhldjayhubiccqcijrgwwpvz` (`name`),
  KEY `idx_hrtogpmgwxfyfrnosntnjzfploueydfcksru` (`handle`),
  KEY `idx_oaobiqshdcvhbhvetkgfkkjynpahylbzhlvy` (`structureId`),
  KEY `idx_eqjuyklirkvwnakflnbocagjzozlrzazeoet` (`fieldLayoutId`),
  KEY `idx_vbdhdodbexcpobmicqesnvsldldeeeeezged` (`dateDeleted`),
  CONSTRAINT `fk_crhatyejzijygwigshhmefrifzpqusndrpql` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ueupxoifimwwqvzhalusyjzorwtacekdskgj` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xdegxlfxxmnpffqxqtejvziujjhhchxfrdmc` (`groupId`,`siteId`),
  KEY `idx_zxhpzdofoknyievijrgcbkrvqvaifigwsivx` (`siteId`),
  CONSTRAINT `fk_gjjsifnhnnamhxmaoykmcghrvzkiefqfwwsh` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gnzozxmfolfkmlvtrogwffwgvqxqscanbcfx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_oajhteawxmluaifokfxugorhaiqtwkgmljzv` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_lwjumzidifmvzxmibeyjpsgdjnprkypyhdng` (`siteId`),
  KEY `fk_ovemczwgcbdcbdxrdllvfpsxlvotojlzapik` (`userId`),
  CONSTRAINT `fk_gsqkgruzjthfylxjnpkrhlllhggtnmtfeuyp` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_lwjumzidifmvzxmibeyjpsgdjnprkypyhdng` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ovemczwgcbdcbdxrdllvfpsxlvotojlzapik` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_rfuaksmfjbwxdpeurnrpiftevchafecvoosn` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_rdeqhxsoqsvnwrroohtefceuntmuoiwadeue` (`siteId`),
  KEY `fk_qawlleiowiyqfblpffdqlbjojoqarziktsej` (`fieldId`),
  KEY `fk_obkbhwbvewnediprrqgfqgsktejqhbrdupjh` (`userId`),
  CONSTRAINT `fk_obkbhwbvewnediprrqgfqgsktejqhbrdupjh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_qawlleiowiyqfblpffdqlbjojoqarziktsej` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rdeqhxsoqsvnwrroohtefceuntmuoiwadeue` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_uihpevpdghlqlmtvvippghluovfrzhvorwfz` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contentblocks`
--

DROP TABLE IF EXISTS `contentblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contentblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_bnymehswpsvqarxlguttpfjbhlvutqfdefzp` (`primaryOwnerId`),
  KEY `idx_haclqitmbfktuitnsoxsrpbyswjwgvfsniiz` (`fieldId`),
  CONSTRAINT `fk_iecamzcitbincchxbywwoxpcbbirlnkzfddo` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sggxmqirqdymmddmvirvabkdhzbqyfergqjc` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uyqncqnfkfmrhaocyzzareydspwidtontffo` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_etrozlrhhiejkumqnqivhzahfrzetewxlhze` (`userId`),
  CONSTRAINT `fk_etrozlrhhiejkumqnqivhzahfrzetewxlhze` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sbmpnixarjgjefhkxztpzwquzgxvifezwazn` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_kpxdznvsbnrpxemuvzfiuqodyzdzkrwbunml` (`creatorId`,`provisional`),
  KEY `idx_aepfcfpycfypfpudbvuwgqdisqkxqavemvsj` (`saved`),
  KEY `fk_afknsbgaibvfrnhyoxlyeggjysqzrhvarlvq` (`canonicalId`),
  CONSTRAINT `fk_afknsbgaibvfrnhyoxlyeggjysqzrhvarlvq` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_aofftcapyrlfpirawwfzthhcqtsfaudqixbx` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_kfmicayjszwyaezdbhiogbzwpyapdvnaluyx` (`elementId`,`timestamp`,`userId`),
  KEY `fk_expbnlomnthhbdqqvymsqfobihwkjbqzkvfs` (`userId`),
  KEY `fk_pzotqlcyriuvvfdnzajymwwmwxhumbqanovv` (`siteId`),
  KEY `fk_kpkopohplxgtfoveaesxfzbsbbcmgvbscxue` (`draftId`),
  CONSTRAINT `fk_expbnlomnthhbdqqvymsqfobihwkjbqzkvfs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fslzaonvuhyfamsvishavdsitpvscotfrrer` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kpkopohplxgtfoveaesxfzbsbbcmgvbscxue` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pzotqlcyriuvvfdnzajymwwmwxhumbqanovv` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_didxqoovyafqjvjylajuubzjjnadkliozgnd` (`dateDeleted`),
  KEY `idx_nkkonwjjutbkfunbetnxkghztxnprbgxawyd` (`fieldLayoutId`),
  KEY `idx_tnzcawaxlqxaiddbpjbavdwbofeamhuxzzbo` (`type`),
  KEY `idx_vpfawoazyibjjwucsvlkutfxxhhuqiwxquab` (`enabled`),
  KEY `idx_wreqtpkewvmnrgayuxqutcjxxzjmhauqwpld` (`canonicalId`),
  KEY `idx_mazfahdycghpgshkwgpfuljuowesryemzwbs` (`archived`,`dateCreated`),
  KEY `idx_krdikvasatopoxftcixnznncqvurpqbttcfj` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_zqifdxdpwfvkumjzbltaqxymcmrcolzksomd` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_cjeorehjzanmgbcbbemqnktssajclovpkmen` (`draftId`),
  KEY `fk_kehghiuirnacrwzsuydhwulaaarmgrfwsjpf` (`revisionId`),
  CONSTRAINT `fk_cjeorehjzanmgbcbbemqnktssajclovpkmen` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kehghiuirnacrwzsuydhwulaaarmgrfwsjpf` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lwqtgkqpwveumvzwnysyamdrnnckwbjonpwh` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rxjvrkhdntcwylfimlpwonupuwsnhbecoaql` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_nnerwlmtayzbebtwsrooukhzzndiedqsmvce` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_idmfdedwyqyknplkxpnvroobwdugzxnkesgn` (`ownerId`),
  CONSTRAINT `fk_bwgiisvmafgvlvbybuvrtqoxlvgfsedlurrc` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_idmfdedwyqyknplkxpnvroobwdugzxnkesgn` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kqwvssglrtojbvrrbhyrjehacctazewgvjtb` (`elementId`,`siteId`),
  KEY `idx_sbpxilnceqmchstikxnxgtuewjgohcpqsaqj` (`siteId`),
  KEY `idx_gfqfqpdxsexdeyolomabwkqeagupmuzttdna` (`title`,`siteId`),
  KEY `idx_glettwfzrigilnhxcjksshxfdpwtinhuabio` (`slug`,`siteId`),
  KEY `idx_itvegnflcmznlwnimlhmmtcyetxpquqzwbln` (`enabled`),
  KEY `idx_gsztrgkidfqjaarhlgdumrunntmgpcoieydz` (`uri`,`siteId`),
  CONSTRAINT `fk_jwloouagtlerlhddulvnbrukxeovqkdiydtj` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_whvjnahlsmvvghxflcxgabslabrmjffictkt` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `status` enum('live','pending','expired') NOT NULL DEFAULT 'live',
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `deletedWithSection` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ypoijdyqwjxeasdnhzekqhbohcanrvaxrksn` (`postDate`),
  KEY `idx_ysiqzaefiwryhaapmnnujadktihbecuyqozk` (`expiryDate`),
  KEY `idx_dzaxuhiyrwvjznkauvdcnzjsgxxfofxwhpqu` (`status`),
  KEY `idx_gktoyxkupelkgqgfcjuuzytvytwwpfyklsew` (`sectionId`),
  KEY `idx_ssvikqcugttzptdlrcsqfhyrmxsddfjfszsi` (`typeId`),
  KEY `idx_reqqgofaqxjxumhbtmwmjuubdxeiyzkttfeb` (`primaryOwnerId`),
  KEY `idx_yrqurbsluacwdpxoqdngazmvbjnlollaybfb` (`fieldId`),
  KEY `fk_jsykyxcxhzcdmifbztrutmutpknqlnumxhmm` (`parentId`),
  CONSTRAINT `fk_axwffybusluaefptlyqljquotofckchgftfx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hqglrzazswavvrpfipimduwutsspbtrmuhjt` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jsykyxcxhzcdmifbztrutmutpknqlnumxhmm` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_lhifhvmcsznpnuimnmjkbnxktzayidahdgtw` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mfsuyleotszbibafxsseyyfvoeljjquxyghp` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ndftzpfhpkxxutrdqvhppmzxiypnamvhkgvg` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_bfherusllnpopifllwhywqarobliitslhwqs` (`authorId`),
  KEY `idx_loptxgzmkgtgozmjwymkzlfkwcfoizlveezl` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_mfaufnugjnahyuvysgsbckmgrsezwuovcgrm` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vajihwyebnjfmvpvjmvzoietjlhesnxnpeef` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jylfzrkcjlapnrpgbheokecajquzhepmwvql` (`fieldLayoutId`),
  KEY `idx_dwumruwprdpjnymssufvqklnfttuevyzzoet` (`dateDeleted`),
  CONSTRAINT `fk_ozoxaalinrioxtjrismahjusphqlkixdzhvn` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_soxdazhgpipqpvftcamvlmrkcqvqykgymlkg` (`dateDeleted`),
  KEY `idx_rryuegpdvgxjivdspzwqhckxwfyyfjhfmigo` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lqwvmjarnebaoyvejqfqhhdtohkdacvouuad` (`handle`,`context`),
  KEY `idx_xmemcnffoawbbwoujfgshejhgfcqyzwmjcag` (`context`),
  KEY `idx_tmrhdawffajkwuhartrxekmyxlafiglwavxb` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vkjimxmguzcbtsglaehxchojylwmmbzwkvyr` (`name`),
  KEY `idx_ejrrfrxinioxultpjnmniyojeekybfosfmdi` (`handle`),
  KEY `idx_befjqwzenbzxcosddlzxbkudgaltmtdjmxha` (`fieldLayoutId`),
  KEY `idx_slrhcszuworzdydymscnjxnbyxdssowkbvgy` (`sortOrder`),
  CONSTRAINT `fk_vljkmmlzzoqpnkwsxnkgyiwtezqmtndghuue` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yyktgdgljczncjpkxdnprqwpihpzifswnenw` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `googlemaps_addresses`
--

DROP TABLE IF EXISTS `googlemaps_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `googlemaps_addresses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `formatted` varchar(255) DEFAULT NULL,
  `raw` text,
  `name` varchar(255) DEFAULT NULL,
  `street1` varchar(255) DEFAULT NULL,
  `street2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `zip` varchar(255) DEFAULT NULL,
  `neighborhood` varchar(255) DEFAULT NULL,
  `county` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `countryCode` varchar(255) DEFAULT NULL,
  `placeId` varchar(255) DEFAULT NULL,
  `lat` decimal(12,8) DEFAULT NULL,
  `lng` decimal(12,8) DEFAULT NULL,
  `zoom` tinyint DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zkkxognrtzdlnsrggptbsruhllvoxvcallnk` (`elementId`,`siteId`,`fieldId`),
  KEY `idx_jeftuxuvnytcathbavlradruiaspfxxkrhpo` (`elementId`),
  KEY `idx_hvglyacuryosthksgnhtoopzjvfndntnxudq` (`siteId`),
  KEY `idx_gqdjvbseecksjouryamcvwfnvokelvzksnvl` (`fieldId`),
  KEY `idx_wuvdwnkoswameqboazvcmbbzwtsqyuaokbll` (`siteId`,`fieldId`),
  KEY `idx_goqhlbvqbihaqpozsfubuseuikxqqncivquk` (`elementId`,`siteId`),
  KEY `idx_vxyhnkcawlryletrcyqdrhvzigzvwouehsin` (`elementId`,`fieldId`),
  CONSTRAINT `fk_crdcpqmobbtbcowrwwsodgnwcchusmjegifv` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ohggreivhmirtzsrcqurnphvfjvhkgeeeoan` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ypvmyetuqmubwdtacebktnyvcgxxwersctam` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rapgnwnhiaybliwwrihtuwcanyhjkhaqjywm` (`accessToken`),
  UNIQUE KEY `idx_sdeqdtuizshxbirzpvkgdrijlcfrbolyhtff` (`name`),
  KEY `fk_xrhxbjpwvyizbmkhzucqkjifpbdmjsyjzzkg` (`schemaId`),
  CONSTRAINT `fk_xrhxbjpwvyizbmkhzucqkjifpbdmjsyjzzkg` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bvwtaajewtgwiuaxdqpqbfrghdnjjrbgbovj` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pvwdebcnchyminpcqrrtsfysmiuyfylltcas` (`name`),
  KEY `idx_apgoxscqcqsfcdmhanbxxbvxatmuirgedkpf` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sonvcawcgalcbdjxuzwrwbsmwaeosenouxhj` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xuzniioxeacpipnvctitozhslqgynqqtdlmk` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_kdertovchemydgdklqeqzhqxvkjcfqkmykhb` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_vneawcvhdezrbpmfpkjntdetfjlicwnixvkh` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pdqqkqpqggasqncizsefxhhnwgalrbahdush` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_lhuhbqneendwdlqbpfdanpuqzdvodxnfkjpk` (`sourceId`),
  KEY `idx_erfnpslrndtmpximnpasfqtkexyclacbdmkf` (`targetId`),
  KEY `idx_uogqlzhhhtsvhcypnkbgbvihvjrifgvssbhs` (`sourceSiteId`),
  CONSTRAINT `fk_aezemsfrmfuersuzqfkwrftgykgafzhfqqqt` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kyiqkysxkovwyojrcqxckwbinzfqtwlogmrg` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wtyhijlyywdyhlnfzhbfypldxowodlzrkgof` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tyvtwrahihgwmksdqodpomghxwnrwpqjyjob` (`canonicalId`,`num`),
  KEY `fk_tlofsimgwozzdmopqvhyibpojigaxqmepvze` (`creatorId`),
  CONSTRAINT `fk_rsywcrzbovmukuewxhjbncagvptdrtrqswol` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tlofsimgwozzdmopqvhyibpojigaxqmepvze` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_itohbcqynwqcfeftorsiuvelbabxekakypyg` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindexqueue`
--

DROP TABLE IF EXISTS `searchindexqueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `reserved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jhwwqboabktzdxiawawhoorwvmvyytzbdcrk` (`elementId`,`siteId`,`reserved`),
  CONSTRAINT `fk_rdzgwdnlebpagbdxvqacgbvqvhyiwzgafcrd` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindexqueue_fields`
--

DROP TABLE IF EXISTS `searchindexqueue_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue_fields` (
  `jobId` int NOT NULL,
  `fieldHandle` varchar(255) NOT NULL,
  PRIMARY KEY (`jobId`,`fieldHandle`),
  UNIQUE KEY `idx_jrnuidmapfoijfkrvqdtercfmxxvzftqdlbk` (`jobId`,`fieldHandle`),
  CONSTRAINT `fk_lnvhrxeyemxsounqhioecmrwllbvnjkbilmq` FOREIGN KEY (`jobId`) REFERENCES `searchindexqueue` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned DEFAULT NULL,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bglramgfqahjawdfhkwjlopemjwvvwhqsmgo` (`handle`),
  KEY `idx_gcsnrbfcmepqzvvisoddeizzpbfbzdshcxez` (`name`),
  KEY `idx_bbuczobpgtzsibavjwxewypgngpkehyttjda` (`structureId`),
  KEY `idx_lgfesnjnxbzgwannrrflkjybxjqcdswceonv` (`dateDeleted`),
  CONSTRAINT `fk_mghfadenyondftfalgkgmpfkceenfmwjusqj` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `handle` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_gtthtgtjsnkklxgmhxbbrtoegwczuwuquauw` (`typeId`),
  CONSTRAINT `fk_gtthtgtjsnkklxgmhxbbrtoegwczuwuquauw` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zatbepxqmchndijezojtxhkyixhhopndxtbf` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_siyiufjbzczxjeegujkwjbmbejvypguennny` (`sectionId`,`siteId`),
  KEY `idx_wfrjneytcpsapwrvxegguyrpagzbxesiqnqn` (`siteId`),
  CONSTRAINT `fk_mctaemiypuynjutvruvxucwurrrxikkswpxb` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vyobqxbtozefouduhtbathnroobysbmdvhsy` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jtffuxeyapkhpnthpvxmktegpqozrtflecfl` (`uid`),
  KEY `idx_febczylqswienddqmumtdyuxlwiolxttbpxx` (`token`),
  KEY `idx_ghkcjvvjpezofdsrmhtpilqaekyohuoueptu` (`dateUpdated`),
  KEY `idx_sgetlcdzfxornygzyqunjtfnbvvpcyfogcqw` (`userId`),
  CONSTRAINT `fk_gdbjxmfquptiznppsnrdtbwtoselfyyattyd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bybwdsnfgnkzmwwdcnpfruhzkzxenvcnzbqc` (`userId`,`message`),
  CONSTRAINT `fk_zpupycywfunorwcquqbjouxnrpapxqzqttkh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tpesbuemohvllasgkzatvxnqxuhuzyjeewlx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ymnmvztxduddssopxuirrfjjstuoroagedrw` (`dateDeleted`),
  KEY `idx_alhwernizqhxnseibobshtunbhmgwzkxfxot` (`handle`),
  KEY `idx_zioftvdhkcpsvdpryvgrhndsydakguhzovfw` (`sortOrder`),
  KEY `fk_paxhywltfinsjyxzrjtvqeqoprvhmhwtzeue` (`groupId`),
  CONSTRAINT `fk_paxhywltfinsjyxzrjtvqeqoprvhmhwtzeue` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sso_identities`
--

DROP TABLE IF EXISTS `sso_identities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_identities` (
  `provider` varchar(255) NOT NULL,
  `identityId` varchar(255) NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`provider`,`identityId`,`userId`),
  KEY `fk_cquefzbseiuebepqkltwgjxsiekqwyuhcgpc` (`userId`),
  CONSTRAINT `fk_cquefzbseiuebepqkltwgjxsiekqwyuhcgpc` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bthbjudrezuwvxksyxeknvejuotgxbyprjeu` (`structureId`,`elementId`),
  KEY `idx_wqzjzpganprvvmwfuodabtcwpcoiqatimott` (`root`),
  KEY `idx_gsuldwfiwokpoqkbhncbdofztmiccbfmbtfw` (`lft`),
  KEY `idx_nkamwpvbhwibhjtckjmtotfdtfdkosrefbvp` (`rgt`),
  KEY `idx_qvieabmwuddbrzchhkpldkzkenthbnrbeicn` (`level`),
  KEY `idx_jxudzmppjfuoijrmcouzeygstvxqhpdxovyd` (`elementId`),
  CONSTRAINT `fk_soucfdspdpwdotjjmmoemzazpfkxjfgasmsg` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cnysqzzbngxuvotdcwnahdyvmcdrrkumznhz` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bqucwziomvgmiokafeaamqybybotnbmccrgy` (`key`,`language`),
  KEY `idx_ukpzrstabviqvfmeaxxzltttelwsbpzhdmpj` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lcjnzhqnmqdzcfawnvpvttjtkgwswuugcnqu` (`name`),
  KEY `idx_yqrgmchhvffelkrtzeyjbpiqoqpizzctrppc` (`handle`),
  KEY `idx_eekoiaywptmatndofiefewdoliymklihriic` (`dateDeleted`),
  KEY `fk_ipcuylcjkfkehsltmksdlscnszxkclwvhdxd` (`fieldLayoutId`),
  CONSTRAINT `fk_ipcuylcjkfkehsltmksdlscnszxkclwvhdxd` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vgdoooxyondracquwtdgxxrztjqwqypkoatz` (`groupId`),
  CONSTRAINT `fk_naznqijrudwjxiedbamwsiaenturtzcfvnhl` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vrpgunwzgrppxnjibwlegelbllwsqzsfmzdp` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_caotjdqvxtfrrblfqxdjnizpulnnqzxlrshq` (`token`),
  KEY `idx_qqxrsklwgxjoflmawfhitjgriuctcdzlotuu` (`expiryDate`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pvgzonzlpmzgiqxtytfrzaxmcueaiaqgvgpf` (`handle`),
  KEY `idx_kzzuxmzsvpfsbhimezcfbisloprfeacelkny` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pegxwllkeuukviqouzfbhwyuwmqrfdosvsxz` (`groupId`,`userId`),
  KEY `idx_hbuagrrwnlwluxwwaamyzsqgchopysbaeryi` (`userId`),
  CONSTRAINT `fk_lxpborqfbggerjxxplflquqjdfuownyijuzf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xlkweyxhibdbcwhokypbauezloowieewtxsd` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dzxkdsddbojtgnzubtnxyhficuxflihniiav` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qsljmmyeaginktldrasmfsvgnnfoehdfllet` (`permissionId`,`groupId`),
  KEY `idx_hbfmfttywqbezvizbetjbiugqnayadhhgobw` (`groupId`),
  CONSTRAINT `fk_dtmxghjopedhugbdxtyaklukjastvufrnjax` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_grditpzvasqeztjzltivalgqamzxxstaaoxh` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_iiztkblafrpqvbkwdkmnioeiliyweejuccqp` (`permissionId`,`userId`),
  KEY `idx_agklyfnsobewjksleexpogilbswsqrvwkvjf` (`userId`),
  CONSTRAINT `fk_arxrrzvzavolvggltderfyeijezuiutlkxzt` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ddzbujpuaivqgkimrgtrlrkjmuofqsjwkxry` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_wkfvkelxgvxxgxmqyubzyeedsliwzvmuwpvw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `affiliatedSiteId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qxuiimgmcjjgtjkkpnxstricrgyhkclxljvp` (`active`),
  KEY `idx_elmgrurrvgheokteyhlitsnqkipwuwsjspac` (`locked`),
  KEY `idx_bmopyrnylqzsuzocububjwuwmwymvacncwmd` (`pending`),
  KEY `idx_gewicsbzkzempnpmkgmadgtmmitxoabhhmhn` (`suspended`),
  KEY `idx_zwvgfhmwbrndxqovonxysjsdpkzkwjuohalk` (`verificationCode`),
  KEY `idx_zvvdzcmdrjxwjpggchmjsmxdtdjaeyacagej` (`email`),
  KEY `idx_emzydscoficdynwjagwwrvzhbbmgwsknebrd` (`username`),
  KEY `fk_gdupqatgydyjgznhqccuzalayelldxcnxwpv` (`photoId`),
  KEY `fk_whywcsbdaudtedgjjrucwaxoomfglqkfzbmo` (`affiliatedSiteId`),
  CONSTRAINT `fk_gdupqatgydyjgznhqccuzalayelldxcnxwpv` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pigqhxenskzdaubsgpvfckuqkyyeptqucdwy` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_whywcsbdaudtedgjjrucwaxoomfglqkfzbmo` FOREIGN KEY (`affiliatedSiteId`) REFERENCES `sites` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ebgqjfuyhhmuerzvjcihetjcmeuqzxldnhiy` (`name`,`parentId`,`volumeId`),
  KEY `idx_oloqzkhhxrctzcpnlyakvzvzdqihkyicpxnn` (`parentId`),
  KEY `idx_fgogyudcyufizzhnvwvfnsobjrkjistgyljc` (`volumeId`),
  CONSTRAINT `fk_dziqcyuxframshhsvsldaiifpqdcmrvswehn` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_toopxvyvrblmfgnueodispiughbupnfgcwue` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jkqtinraasezxbbmutvvxzlmewnrhfctrerm` (`name`),
  KEY `idx_deynmqwqolvppznwtgnbxwwbqpnthyztidok` (`handle`),
  KEY `idx_rszxcxwcdcwnmuzyycppxdajkifogosxgveq` (`fieldLayoutId`),
  KEY `idx_orrwpdyfsqzltnupepzlvosdcopencouhsga` (`dateDeleted`),
  CONSTRAINT `fk_bubzhopxwjpfpogomdxgtdpuajizixqimvgs` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_hcmbrtmnrxgntsdsqnwoalichynfhcyhsfjc` (`userId`),
  CONSTRAINT `fk_hcmbrtmnrxgntsdsqnwoalichynfhcyhsfjc` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eegksbdquntsxkrfzhbrlnzzggjsphnsoqdr` (`userId`),
  CONSTRAINT `fk_fhidgnnnbzvunuzhedcerwsoofxncmwqdwau` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-02 20:22:55
-- MySQL dump 10.13  Distrib 8.0.40, for Linux (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `addresses` VALUES (6,4,2,'US','NY','Schenectady','','12303','','1166 Chrisler Ave','','','','','','','','','','2025-08-29 01:40:17','2025-08-29 01:40:53'),(8,7,2,'US','NY','Schenectady','','12303','','1166 Chrisler Ave','','','','','','','','','','2025-08-29 01:42:02','2025-08-29 01:42:02'),(12,11,2,'US','NY','New York','','10012','','69 Green St.','','','','','','','','','','2025-08-29 02:14:44','2025-08-29 02:15:33'),(15,14,2,'US','NY','New York','','10012','','69 Green St.','','','','','','','','','','2025-08-29 02:16:35','2025-08-29 02:16:35');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets` VALUES (5,1,3,1,'dandy.jpg','image/jpeg','image',NULL,3887,2591,749770,NULL,NULL,NULL,'2025-08-29 01:39:51','2025-08-29 01:39:51','2025-08-29 01:39:51'),(13,1,3,1,'IMG_0575.JPG','image/jpeg','image',NULL,3472,2320,3082519,NULL,NULL,NULL,'2025-08-29 02:16:29','2025-08-29 02:16:29','2025-08-29 02:16:29');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets_sites` VALUES (5,1,NULL),(13,1,NULL);
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `bulkopevents`
--

LOCK TABLES `bulkopevents` WRITE;
/*!40000 ALTER TABLE `bulkopevents` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `bulkopevents` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `categories` VALUES (22,1,NULL,NULL,'2025-08-30 01:34:47','2025-08-30 01:34:47'),(23,1,NULL,NULL,'2025-08-30 01:35:12','2025-08-30 01:35:12'),(24,1,NULL,NULL,'2025-08-30 01:35:26','2025-08-30 01:35:26'),(25,1,NULL,NULL,'2025-08-30 01:35:37','2025-08-30 01:35:37'),(26,1,NULL,NULL,'2025-08-30 01:35:49','2025-08-30 01:35:49');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `categorygroups` VALUES (1,2,4,'Category','category','end','2025-08-30 01:34:42','2025-08-30 01:37:25',NULL,'fc73028f-e956-417d-a9cb-27cf6b5d2777');
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `categorygroups_sites` VALUES (1,1,1,1,'category/{slug}','category/_category.twig','2025-08-30 01:34:42','2025-08-30 01:37:25','b19945af-342a-417d-b4e8-7220746e597a');
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedattributes` VALUES (1,1,'firstName','2025-08-30 02:54:06',0,1),(1,1,'fullName','2025-08-30 02:54:06',0,1),(1,1,'lastName','2025-08-30 02:54:06',0,1),(4,1,'postDate','2025-08-29 01:42:02',0,1),(4,1,'slug','2025-08-29 01:40:03',0,1),(4,1,'title','2025-08-29 01:40:03',0,1),(4,1,'uri','2025-08-29 01:40:03',0,1),(6,1,'addressLine1','2025-08-29 01:40:35',0,1),(6,1,'administrativeArea','2025-08-29 01:40:40',0,1),(6,1,'locality','2025-08-29 01:40:49',0,1),(6,1,'postalCode','2025-08-29 01:40:53',0,1),(6,1,'title','2025-08-29 01:40:25',0,1),(11,1,'postDate','2025-08-29 02:16:35',0,1),(11,1,'slug','2025-08-29 02:14:22',0,1),(11,1,'title','2025-08-29 02:14:22',0,1),(11,1,'uri','2025-08-29 02:14:22',0,1),(12,1,'addressLine1','2025-08-29 02:15:14',0,1),(12,1,'administrativeArea','2025-08-29 02:15:23',0,1),(12,1,'locality','2025-08-29 02:15:28',0,1),(12,1,'postalCode','2025-08-29 02:15:33',0,1),(12,1,'title','2025-08-29 02:15:06',0,1),(17,1,'slug','2025-08-29 03:33:10',0,1),(17,1,'title','2025-08-29 03:33:10',0,1),(22,1,'slug','2025-08-30 01:35:02',0,1),(22,1,'title','2025-08-30 01:35:07',0,1),(22,1,'uri','2025-08-30 01:35:02',0,1),(23,1,'slug','2025-08-30 01:35:21',0,1),(23,1,'title','2025-08-30 01:35:21',0,1),(23,1,'uri','2025-08-30 01:35:21',0,1),(24,1,'slug','2025-08-30 01:35:32',0,1),(24,1,'title','2025-08-30 01:35:32',0,1),(24,1,'uri','2025-08-30 01:35:32',0,1),(25,1,'slug','2025-08-30 01:35:42',0,1),(25,1,'title','2025-08-30 01:35:42',0,1),(25,1,'uri','2025-08-30 01:35:42',0,1),(26,1,'slug','2025-08-30 01:35:58',0,1),(26,1,'title','2025-08-30 01:35:58',0,1),(26,1,'uri','2025-08-30 01:35:58',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES (4,1,1,'b0b232e8-582d-4134-866c-0df5c8676231','2025-08-30 01:39:24',0,1),(4,1,2,'064e31eb-3259-47e6-ad42-baa6e07c6bc0','2025-08-29 01:40:17',0,1),(4,1,3,'4a71ac0d-c816-4eb2-b03c-3084d1f01fbe','2025-08-29 01:39:54',0,1),(4,1,4,'cb834a18-7534-4ad0-824f-2fef5b3fcfca','2025-08-29 01:41:33',0,1),(4,1,5,'458ec52d-1155-45bd-a853-39bf9d61d8d8','2025-08-29 01:41:46',0,1),(4,1,8,'081ff5c0-c59f-4323-abaf-289ab43b6295','2025-08-30 01:39:24',0,1),(4,1,9,'1a1e0f44-450f-4411-ac10-d5c3c676a549','2025-08-30 01:39:24',0,1),(11,1,1,'b0b232e8-582d-4134-866c-0df5c8676231','2025-08-29 02:14:43',0,1),(11,1,2,'064e31eb-3259-47e6-ad42-baa6e07c6bc0','2025-08-29 02:14:44',0,1),(11,1,3,'4a71ac0d-c816-4eb2-b03c-3084d1f01fbe','2025-08-29 02:16:32',0,1),(17,1,7,'1631a573-2528-4ea7-9b03-26da53cde2de','2025-08-29 03:33:05',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `contentblocks`
--

LOCK TABLES `contentblocks` WRITE;
/*!40000 ALTER TABLE `contentblocks` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `contentblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `drafts` VALUES (1,NULL,1,0,'First draft',NULL,0,NULL,0),(2,NULL,1,0,'First draft',NULL,0,NULL,0),(8,NULL,1,0,'First draft',NULL,0,NULL,1);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elementactivity` VALUES (4,1,1,NULL,'edit','2025-08-30 01:39:17'),(4,1,1,NULL,'save','2025-08-30 01:39:24'),(4,1,1,NULL,'view','2025-08-30 01:39:13'),(6,1,1,NULL,'save','2025-08-29 01:40:53'),(11,1,1,NULL,'save','2025-08-29 02:16:35'),(11,1,1,NULL,'view','2025-08-30 02:29:44'),(12,1,1,NULL,'save','2025-08-29 02:15:37'),(17,1,1,NULL,'save','2025-08-29 03:33:10'),(22,1,1,NULL,'save','2025-08-30 01:35:09'),(22,1,1,NULL,'view','2025-08-30 01:35:02'),(23,1,1,NULL,'save','2025-08-30 01:35:23'),(23,1,1,NULL,'view','2025-08-30 01:35:12'),(24,1,1,NULL,'save','2025-08-30 01:35:33'),(24,1,1,NULL,'view','2025-08-30 01:35:26'),(25,1,1,NULL,'save','2025-08-30 01:35:43'),(25,1,1,NULL,'view','2025-08-30 01:35:38'),(26,1,1,NULL,'save','2025-08-30 01:35:59'),(26,1,1,NULL,'view','2025-08-30 01:35:49');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2025-08-27 01:52:15','2025-08-30 02:54:06',NULL,NULL,NULL,'8b783630-c768-4fd0-b566-c3a8bd6b778a'),(2,NULL,1,NULL,1,'craft\\elements\\Entry',1,0,'2025-08-29 01:36:01','2025-08-29 01:36:01',NULL,NULL,NULL,'f43e19d4-ab30-4f26-90ae-0bcf24696e6f'),(3,NULL,2,NULL,1,'craft\\elements\\Entry',1,0,'2025-08-29 01:38:39','2025-08-29 01:38:39',NULL,NULL,NULL,'3129fc50-9e85-4109-ad96-9faa54eeadbe'),(4,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2025-08-29 01:39:21','2025-08-30 01:39:24',NULL,NULL,NULL,'7595d0de-91a4-4732-b068-a345063f6b8e'),(5,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2025-08-29 01:39:50','2025-08-29 01:39:50',NULL,NULL,NULL,'c598f9ad-4863-4624-b642-8c5ed5441655'),(6,NULL,NULL,NULL,NULL,'craft\\elements\\Address',1,0,'2025-08-29 01:40:17','2025-08-29 01:40:53',NULL,NULL,NULL,'0ef8354e-e80b-4d6f-a3df-f9c7bd0732f6'),(7,4,NULL,1,1,'craft\\elements\\Entry',1,0,'2025-08-29 01:42:02','2025-08-29 01:42:02',NULL,NULL,NULL,'11fd422f-289b-4de4-be33-0bad9a6bb305'),(8,6,NULL,2,NULL,'craft\\elements\\Address',1,0,'2025-08-29 01:40:53','2025-08-29 01:42:02',NULL,NULL,NULL,'b88fe4fc-a7be-44f3-ab39-39aa5d093805'),(9,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2025-08-29 01:45:09','2025-08-29 01:45:09',NULL,NULL,NULL,'b138e6f7-be72-477d-8531-7e70e3650c2d'),(10,9,NULL,3,1,'craft\\elements\\Entry',1,0,'2025-08-29 01:45:09','2025-08-29 01:45:09',NULL,NULL,NULL,'dffcc5ad-4f5f-46c2-af00-f1fddb6278e2'),(11,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2025-08-29 02:14:05','2025-08-29 02:16:35',NULL,NULL,NULL,'6cacdb9c-b3ee-43c6-8e37-6d691dd668ac'),(12,NULL,NULL,NULL,NULL,'craft\\elements\\Address',1,0,'2025-08-29 02:14:44','2025-08-29 02:15:37',NULL,NULL,NULL,'e463267b-afa7-460a-9da1-dcac421f5f8d'),(13,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2025-08-29 02:16:28','2025-08-29 02:16:28',NULL,NULL,NULL,'3fccf2e6-a406-48a7-8592-6d36756c47f6'),(14,11,NULL,4,1,'craft\\elements\\Entry',1,0,'2025-08-29 02:16:35','2025-08-29 02:16:35',NULL,NULL,NULL,'2fdf756d-54e5-4f76-80b2-3cf5770a2fb3'),(15,12,NULL,5,NULL,'craft\\elements\\Address',1,0,'2025-08-29 02:15:37','2025-08-29 02:16:35',NULL,NULL,NULL,'65e5627f-d165-4ac7-a53b-a231a7f4da65'),(17,NULL,8,NULL,3,'craft\\elements\\Entry',1,0,'2025-08-29 03:16:05','2025-08-29 03:36:49',NULL,'2025-08-29 03:36:49',NULL,'ab942ed7-04ed-4bfa-959a-e47fcc051061'),(22,NULL,NULL,NULL,4,'craft\\elements\\Category',1,0,'2025-08-30 01:34:47','2025-08-30 01:35:09',NULL,NULL,NULL,'a2b91f70-4792-474a-988d-4e0124284993'),(23,NULL,NULL,NULL,4,'craft\\elements\\Category',1,0,'2025-08-30 01:35:12','2025-08-30 01:35:23',NULL,NULL,NULL,'af2997d5-cba2-41af-9e02-b34c26960607'),(24,NULL,NULL,NULL,4,'craft\\elements\\Category',1,0,'2025-08-30 01:35:26','2025-08-30 01:35:33',NULL,NULL,NULL,'5ec4b0e6-b08e-4551-a991-3ffa739cbc49'),(25,NULL,NULL,NULL,4,'craft\\elements\\Category',1,0,'2025-08-30 01:35:37','2025-08-30 01:35:43',NULL,NULL,NULL,'da591109-15c1-41cc-a618-d7aa17839bfd'),(26,NULL,NULL,NULL,4,'craft\\elements\\Category',1,0,'2025-08-30 01:35:49','2025-08-30 01:35:59',NULL,NULL,NULL,'ecad18d9-1909-44b1-9888-d5ea427649ac'),(27,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2025-08-30 01:39:24','2025-08-30 01:39:24',NULL,NULL,NULL,'ef3c928d-193d-452c-83a6-d37c91a73cc3'),(28,4,NULL,6,1,'craft\\elements\\Entry',1,0,'2025-08-30 01:39:24','2025-08-30 01:39:24',NULL,NULL,NULL,'9a002e2c-92ed-479d-9d65-a48444159bf5'),(29,27,NULL,7,3,'craft\\elements\\Entry',1,0,'2025-08-30 01:39:24','2025-08-30 01:39:24',NULL,NULL,NULL,'41e90e6c-71ad-48e7-a0b1-248deae90bab');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_owners` VALUES (6,4,1),(8,7,1),(8,28,1),(12,11,1),(15,14,1),(27,4,2),(29,28,2);
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2025-08-27 01:52:15','2025-08-27 01:52:15','a1f7e182-ae40-421a-8201-6183afc5d146'),(2,2,1,NULL,'__temp_rrzbddfbtlpllkfzyjebtjblouovdgptntto','business/__temp_rrzbddfbtlpllkfzyjebtjblouovdgptntto',NULL,1,'2025-08-29 01:36:01','2025-08-29 01:36:01','0f917dc3-2276-4178-8640-42fb42257dbf'),(3,3,1,NULL,'__temp_ivrtaxscgacdrqbrqixavqisyiitsgyvdnvm','business/__temp_ivrtaxscgacdrqbrqixavqisyiitsgyvdnvm',NULL,1,'2025-08-29 01:38:39','2025-08-29 01:38:39','384cb152-362e-4169-bba1-fdd6f364c096'),(4,4,1,'Drug Farm','drug-farm','business/drug-farm','{\"1a1e0f44-450f-4411-ac10-d5c3c676a549\": [22], \"458ec52d-1155-45bd-a853-39bf9d61d8d8\": {\"type\": \"url\", \"value\": \"https://google.com\"}, \"4a71ac0d-c816-4eb2-b03c-3084d1f01fbe\": [5], \"b0b232e8-582d-4134-866c-0df5c8676231\": \"drigs@drug.com\", \"cb834a18-7534-4ad0-824f-2fef5b3fcfca\": {\"type\": \"tel\", \"value\": \"tel:5183741672\"}}',1,'2025-08-29 01:39:21','2025-08-30 01:39:24','eb5d0ea1-3779-4a64-81bb-c9401f1a6b8b'),(5,5,1,'Dandy',NULL,NULL,NULL,1,'2025-08-29 01:39:50','2025-08-29 01:39:50','7e25179a-909c-42b3-ac49-7d293ffbb22f'),(6,6,1,'My House','__temp_qwqushrkpopwjchalbvappxrshvvyoxpafif',NULL,NULL,1,'2025-08-29 01:40:17','2025-08-29 01:40:25','05211293-a24f-46a9-8752-87c740746fb0'),(7,7,1,'Drug Farm','drug-farm','business/drug-farm','{\"458ec52d-1155-45bd-a853-39bf9d61d8d8\": {\"type\": \"url\", \"value\": \"https://google.com\"}, \"4a71ac0d-c816-4eb2-b03c-3084d1f01fbe\": [5], \"b0b232e8-582d-4134-866c-0df5c8676231\": \"drigs@drug.com\", \"cb834a18-7534-4ad0-824f-2fef5b3fcfca\": {\"type\": \"tel\", \"value\": \"tel:5183741672\"}}',1,'2025-08-29 01:42:02','2025-08-29 01:42:02','669b16a3-7183-48b1-820b-d8e5e40a59d0'),(8,8,1,'My House','__temp_qwqushrkpopwjchalbvappxrshvvyoxpafif',NULL,NULL,1,'2025-08-29 01:42:02','2025-08-29 01:42:02','720ec0e3-800e-4cec-899c-12a254f2ec17'),(9,9,1,'Business Listing','business-listing','business','{\"4a71ac0d-c816-4eb2-b03c-3084d1f01fbe\": []}',1,'2025-08-29 01:45:09','2025-08-29 01:45:09','55952c25-f8f6-4347-a906-c91daa25c098'),(10,10,1,'Business Listing','business-listing','business','{\"4a71ac0d-c816-4eb2-b03c-3084d1f01fbe\": []}',1,'2025-08-29 01:45:09','2025-08-29 01:45:09','285c8608-b049-42f5-976a-f0f0ec5f6089'),(11,11,1,'The Other Drug Farm','the-other-drug-farm','business/the-other-drug-farm','{\"4a71ac0d-c816-4eb2-b03c-3084d1f01fbe\": [13], \"b0b232e8-582d-4134-866c-0df5c8676231\": \"jackiejones@bboblah.com\"}',1,'2025-08-29 02:14:05','2025-08-29 02:16:32','121214d6-9b41-4267-afb4-8b802e2580f6'),(12,12,1,'The Other Drug Farm','__temp_qxeldaxhkkivhtbycqzdxdyuhltttbpytxga',NULL,NULL,1,'2025-08-29 02:14:44','2025-08-29 02:15:06','680d3443-1cbd-4e6a-859c-c447c9faa00b'),(13,13,1,'IMG 0575',NULL,NULL,NULL,1,'2025-08-29 02:16:28','2025-08-29 02:16:28','786afaec-9896-4ac4-8c78-a4ec4fe2d9d2'),(14,14,1,'The Other Drug Farm','the-other-drug-farm','business/the-other-drug-farm','{\"4a71ac0d-c816-4eb2-b03c-3084d1f01fbe\": [13], \"b0b232e8-582d-4134-866c-0df5c8676231\": \"jackiejones@bboblah.com\"}',1,'2025-08-29 02:16:35','2025-08-29 02:16:35','48b272b0-869a-4360-9f38-9ab0325bb52a'),(15,15,1,'The Other Drug Farm','__temp_qxeldaxhkkivhtbycqzdxdyuhltttbpytxga',NULL,NULL,1,'2025-08-29 02:16:35','2025-08-29 02:16:35','7b9a31eb-39f5-4424-b421-7f9b552f11ca'),(17,17,1,'funny','__temp_ibtlgqsieknnwpqqzmqgzvqtmxmmzrebynxe',NULL,'{\"1631a573-2528-4ea7-9b03-26da53cde2de\": [{\"col1\": \"\", \"col2\": \"\", \"col3\": \"\", \"col4\": \"\", \"col5\": \"\", \"col6\": \"\", \"col7\": \"\", \"col8\": \"\", \"col9\": \"\", \"col10\": \"\", \"col11\": \"\", \"col12\": \"\", \"col13\": \"\"}]}',1,'2025-08-29 03:16:05','2025-08-29 03:33:10','d0694a41-3ec7-4238-9783-58ce6dd75cbf'),(22,22,1,'Health & Beauty','health-beauty','category/health-beauty',NULL,1,'2025-08-30 01:34:47','2025-08-30 01:37:25','9671efdb-e728-4052-af87-1fbf17e8b52a'),(23,23,1,'Retail','retail','category/retail',NULL,1,'2025-08-30 01:35:12','2025-08-30 01:37:25','9f44977e-14e9-4b78-b387-0a298dc3d0e5'),(24,24,1,'Entertainment','entertainment','category/entertainment',NULL,1,'2025-08-30 01:35:26','2025-08-30 01:37:25','c8fe8523-f953-4464-b5a1-208296aa1ea3'),(25,25,1,'Services','services','category/services',NULL,1,'2025-08-30 01:35:37','2025-08-30 01:37:25','4e969eb6-4601-46a7-b480-df309f8775fa'),(26,26,1,'Food & Beverage','food-beverage','category/food-beverage',NULL,1,'2025-08-30 01:35:49','2025-08-30 01:37:25','150d0aa1-60bb-4e87-9bc3-ec25297fdaef'),(27,27,1,'Drug Specials','drug-specials',NULL,'{\"1631a573-2528-4ea7-9b03-26da53cde2de\": [{\"col14\": \"January\", \"col15\": \"Free Drugs\"}, {\"col14\": \"February\", \"col15\": \"\"}, {\"col14\": \"March\", \"col15\": \"\"}, {\"col14\": \"April\", \"col15\": \"\"}, {\"col14\": \"May\", \"col15\": \"\"}, {\"col14\": \"June\", \"col15\": \"\"}, {\"col14\": \"July\", \"col15\": \"\"}, {\"col14\": \"August\", \"col15\": \"\"}, {\"col14\": \"September\", \"col15\": \"\"}, {\"col14\": \"October\", \"col15\": \"\"}, {\"col14\": \"November\", \"col15\": \"\"}, {\"col14\": \"December\", \"col15\": \"\"}], \"dce02115-1f00-4201-b877-527c57df8c3f\": \"Free drugs!\"}',1,'2025-08-30 01:39:24','2025-08-30 01:39:24','c3eb5f65-a9f5-4f9f-b8dd-c1e51a44af5c'),(28,28,1,'Drug Farm','drug-farm','business/drug-farm','{\"1a1e0f44-450f-4411-ac10-d5c3c676a549\": [22], \"458ec52d-1155-45bd-a853-39bf9d61d8d8\": {\"type\": \"url\", \"value\": \"https://google.com\"}, \"4a71ac0d-c816-4eb2-b03c-3084d1f01fbe\": [5], \"b0b232e8-582d-4134-866c-0df5c8676231\": \"drigs@drug.com\", \"cb834a18-7534-4ad0-824f-2fef5b3fcfca\": {\"type\": \"tel\", \"value\": \"tel:5183741672\"}}',1,'2025-08-30 01:39:24','2025-08-30 01:39:24','67fcefb9-1e63-4831-991b-6baeb7ebaa24'),(29,29,1,'Drug Specials','drug-specials',NULL,'{\"1631a573-2528-4ea7-9b03-26da53cde2de\": [{\"col14\": \"January\", \"col15\": \"Free Drugs\"}, {\"col14\": \"February\", \"col15\": \"\"}, {\"col14\": \"March\", \"col15\": \"\"}, {\"col14\": \"April\", \"col15\": \"\"}, {\"col14\": \"May\", \"col15\": \"\"}, {\"col14\": \"June\", \"col15\": \"\"}, {\"col14\": \"July\", \"col15\": \"\"}, {\"col14\": \"August\", \"col15\": \"\"}, {\"col14\": \"September\", \"col15\": \"\"}, {\"col14\": \"October\", \"col15\": \"\"}, {\"col14\": \"November\", \"col15\": \"\"}, {\"col14\": \"December\", \"col15\": \"\"}], \"dce02115-1f00-4201-b877-527c57df8c3f\": \"Free drugs!\"}',1,'2025-08-30 01:39:24','2025-08-30 01:39:24','02d8f428-39ac-4cd9-9662-c3332612db2a');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (2,1,NULL,NULL,NULL,1,'2025-08-29 01:36:01',NULL,'live',NULL,NULL,'2025-08-29 01:36:01','2025-08-29 01:36:01'),(3,1,NULL,NULL,NULL,1,'2025-08-29 01:38:39',NULL,'live',NULL,NULL,'2025-08-29 01:38:39','2025-08-29 01:38:39'),(4,1,NULL,NULL,NULL,1,'2025-08-29 01:42:00',NULL,'live',NULL,NULL,'2025-08-29 01:39:21','2025-08-29 01:42:02'),(7,1,NULL,NULL,NULL,1,'2025-08-29 01:42:00',NULL,'live',NULL,NULL,'2025-08-29 01:42:02','2025-08-29 01:42:02'),(9,2,NULL,NULL,NULL,1,'2025-08-29 01:45:00',NULL,'live',NULL,NULL,'2025-08-29 01:45:09','2025-08-29 01:45:09'),(10,2,NULL,NULL,NULL,1,'2025-08-29 01:45:00',NULL,'live',NULL,NULL,'2025-08-29 01:45:09','2025-08-29 01:45:09'),(11,1,NULL,NULL,NULL,1,'2025-08-29 02:16:00',NULL,'live',NULL,NULL,'2025-08-29 02:14:05','2025-08-29 02:16:35'),(14,1,NULL,NULL,NULL,1,'2025-08-29 02:16:00',NULL,'live',NULL,NULL,'2025-08-29 02:16:35','2025-08-29 02:16:35'),(27,NULL,NULL,4,8,2,'2025-08-29 03:38:00',NULL,'live',NULL,NULL,'2025-08-30 01:39:24','2025-08-30 01:39:24'),(28,1,NULL,NULL,NULL,1,'2025-08-29 01:42:00',NULL,'live',NULL,NULL,'2025-08-30 01:39:24','2025-08-30 01:39:24'),(29,NULL,NULL,28,8,2,'2025-08-29 03:38:00',NULL,'live',NULL,NULL,'2025-08-30 01:39:24','2025-08-30 01:39:24');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries_authors` VALUES (2,1,1),(3,1,1),(4,1,1),(7,1,1),(11,1,1),(14,1,1),(28,1,1);
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,1,'Business','business',NULL,NULL,NULL,1,'site',NULL,NULL,1,'site',NULL,1,'2025-08-29 01:35:31','2025-08-29 01:35:31',NULL,'9d21a74f-c6b5-434c-8ed2-c75251a61c26'),(2,3,'Monthly Special','monthlySpecial',NULL,NULL,NULL,1,'site',NULL,NULL,1,'site',NULL,1,'2025-08-29 03:15:47','2025-08-29 03:15:47',NULL,'998d77d7-e6eb-4b75-842f-ae8280fba567');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"d46d188c-2f64-44c8-8aaa-c0ef97964401\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"cc37d22a-3bb3-4fcb-8b7b-2cee8691d5c6\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2025-08-29T01:28:18+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"1a1e0f44-450f-4411-ac10-d5c3c676a549\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"abca8568-b497-484e-b4d3-5fe77d0d18dd\", \"required\": false, \"dateAdded\": \"2025-08-30T01:38:51+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"b0b232e8-582d-4134-866c-0df5c8676231\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"1681a684-620d-404c-a918-6af20caa8b8b\", \"required\": false, \"dateAdded\": \"2025-08-29T01:35:31+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"064e31eb-3259-47e6-ad42-baa6e07c6bc0\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"937faf23-8b1b-469b-9235-401505a750f2\", \"required\": false, \"dateAdded\": \"2025-08-29T01:35:31+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"4a71ac0d-c816-4eb2-b03c-3084d1f01fbe\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3\", \"required\": false, \"dateAdded\": \"2025-08-29T01:35:31+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"cb834a18-7534-4ad0-824f-2fef5b3fcfca\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"90c4ffa5-83bb-4af6-8837-6ad5bf1c323c\", \"required\": false, \"dateAdded\": \"2025-08-29T01:35:31+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"458ec52d-1155-45bd-a853-39bf9d61d8d8\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"b441d323-0b33-4f14-95c6-153d91a1674d\", \"required\": false, \"dateAdded\": \"2025-08-29T01:35:31+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"081ff5c0-c59f-4323-abaf-289ab43b6295\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb\", \"required\": false, \"dateAdded\": \"2025-08-29T03:15:52+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-08-29 01:35:31','2025-08-30 01:38:51',NULL,'12f8c6de-4ca2-4da7-b1cb-827f4e01968d'),(2,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"d9c173c2-b7cf-442b-b899-51d82ad30990\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"c3c168f4-14fb-4d22-9f89-ce6eb5b459d2\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2025-08-29T01:36:43+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-08-29 01:38:12','2025-08-29 01:38:12',NULL,'8f2c97e0-7ee4-483c-9d4f-108e15699bc8'),(3,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"e9dd146c-92c1-4819-845e-e9a371e1f1ba\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"76fcb0b5-620e-4508-8975-ff69f718b211\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": true, \"dateAdded\": \"2025-08-29T03:09:43+00:00\", \"inputType\": null, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"dce02115-1f00-4201-b877-527c57df8c3f\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"21d5b2e7-055d-41a3-8842-86406bf86748\", \"required\": false, \"dateAdded\": \"2025-08-29T03:15:47+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"1631a573-2528-4ea7-9b03-26da53cde2de\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"a955ad2a-a4f5-4a2d-ad4a-d844e4d15140\", \"required\": false, \"dateAdded\": \"2025-08-29T03:15:47+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-08-29 03:15:47','2025-08-29 03:15:47',NULL,'f4ae60e4-3042-44f1-a5c9-de232d6376fa'),(4,'craft\\elements\\Category','{\"tabs\": [{\"uid\": \"ec1ec6d1-a6c6-4ae7-ab14-13c81d77c640\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"fdb72ffa-b710-4a5c-9dd7-090155fbdcc6\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\TitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2025-08-30T01:33:24+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [], \"generatedFields\": [], \"cardThumbAlignment\": \"end\"}','2025-08-30 01:34:42','2025-08-30 01:34:42',NULL,'24788bcc-ece8-4ed4-b4a9-4330ef55cd37');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (1,'Business Email','businessEmail','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Email','{\"placeholder\":null}','2025-08-29 01:30:06','2025-08-29 01:30:06',NULL,'1681a684-620d-404c-a918-6af20caa8b8b'),(2,'Business Address','businessAddress','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Addresses','{\"maxAddresses\":null,\"minAddresses\":null,\"viewMode\":\"cards\"}','2025-08-29 01:31:20','2025-08-29 01:31:20',NULL,'937faf23-8b1b-469b-9235-401505a750f2'),(3,'Business Images','businessImages','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultPlacement\":\"end\",\"defaultUploadLocationSource\":\"volume:56699230-c9fb-4962-9d9b-36f4224b5a07\",\"defaultUploadLocationSubpath\":\"business\",\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:56699230-c9fb-4962-9d9b-36f4224b5a07\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSearchInput\":true,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2025-08-29 01:32:28','2025-08-29 01:39:15',NULL,'bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3'),(4,'Business Phone','businessPhone','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Link','{\"fullGraphqlData\":true,\"maxLength\":255,\"showLabelField\":false,\"types\":[\"tel\"]}','2025-08-29 01:33:38','2025-08-29 01:41:20',NULL,'90c4ffa5-83bb-4af6-8837-6ad5bf1c323c'),(5,'Business Website','businessWebsite','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Link','{\"fullGraphqlData\":true,\"maxLength\":255,\"showLabelField\":false,\"typeSettings\":{\"url\":{\"allowRootRelativeUrls\":\"\",\"allowAnchors\":\"\",\"allowCustomSchemes\":\"\"}},\"types\":[\"url\"]}','2025-08-29 01:34:24','2025-08-29 01:41:58',NULL,'b441d323-0b33-4f14-95c6-153d91a1674d'),(6,'One Special (same each month)','oneSpecial','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-08-29 03:12:49','2025-08-29 03:12:49',NULL,'21d5b2e7-055d-41a3-8842-86406bf86748'),(7,'Multiple Specials','multipleSpecials','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Table','{\"addRowLabel\":\"Add a row\",\"columns\":{\"col14\":{\"heading\":\"Month\",\"handle\":\"month\",\"width\":\"\",\"type\":\"singleline\"},\"col15\":{\"heading\":\"Special\",\"handle\":\"special\",\"width\":\"\",\"type\":\"singleline\"}},\"defaults\":[{\"col14\":\"January\",\"col15\":\"\"},{\"col14\":\"February\",\"col15\":\"\"},{\"col14\":\"March\",\"col15\":\"\"},{\"col14\":\"April\",\"col15\":\"\"},{\"col14\":\"May\",\"col15\":\"\"},{\"col14\":\"June\",\"col15\":\"\"},{\"col14\":\"July\",\"col15\":\"\"},{\"col14\":\"August\",\"col15\":\"\"},{\"col14\":\"September\",\"col15\":\"\"},{\"col14\":\"October\",\"col15\":\"\"},{\"col14\":\"November\",\"col15\":\"\"},{\"col14\":\"December\",\"col15\":\"\"}],\"maxRows\":null,\"minRows\":null,\"staticRows\":true}','2025-08-29 03:15:42','2025-08-29 03:36:26',NULL,'a955ad2a-a4f5-4a2d-ad4a-d844e4d15140'),(8,'Business Specials','businessSpecials','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":null,\"defaultIndexViewMode\":\"cards\",\"enableVersioning\":false,\"entryTypes\":[{\"uid\":\"998d77d7-e6eb-4b75-842f-ae8280fba567\",\"group\":\"General\"}],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":null,\"pageSize\":50,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"cards\"}','2025-08-29 03:15:49','2025-08-29 03:15:49',NULL,'1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb'),(9,'Category','category','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Categories','{\"allowSelfRelations\":false,\"branchLimit\":null,\"defaultPlacement\":\"end\",\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSearchInput\":true,\"showSiteMenu\":false,\"source\":\"group:fc73028f-e956-417d-a9cb-27cf6b5d2777\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2025-08-30 01:38:42','2025-08-30 01:38:42',NULL,'abca8568-b497-484e-b4d3-5fe77d0d18dd');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `googlemaps_addresses`
--

LOCK TABLES `googlemaps_addresses` WRITE;
/*!40000 ALTER TABLE `googlemaps_addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `googlemaps_addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'5.8.16','5.8.0.3',0,'tkikgdfuxkxl','3@cweebmhwxk','2025-08-27 01:52:15','2025-09-02 23:20:17','dd3424d1-9af1-4337-8856-fc73572dd076');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,'craft','Install','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','becd3c0d-b158-4b7a-8255-f9ab31de823e'),(2,'craft','m221101_115859_create_entries_authors_table','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','458cbde6-5b60-41f0-b08e-8cedebe7dcad'),(3,'craft','m221107_112121_add_max_authors_to_sections','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','151f834c-0a36-4909-a57b-ec67bc79ec73'),(4,'craft','m221205_082005_translatable_asset_alt_text','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','e18f2838-e02f-4451-aebe-85c8e729787a'),(5,'craft','m230314_110309_add_authenticator_table','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','602f70e7-610f-4c38-8d71-ecbd12694b11'),(6,'craft','m230314_111234_add_webauthn_table','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','6842c2ed-df76-46d0-a416-2d46e27ce36b'),(7,'craft','m230503_120303_add_recoverycodes_table','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','d4c48904-170e-4bf8-a1be-a8cdb4e6f887'),(8,'craft','m230511_000000_field_layout_configs','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','099197e4-9d90-4d05-a619-c743f53ed11d'),(9,'craft','m230511_215903_content_refactor','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','a67339a2-2462-4e60-b6d5-107e938f2f6c'),(10,'craft','m230524_000000_add_entry_type_show_slug_field','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','5e67dff1-3b45-4e5c-a3f6-202a9b9746dd'),(11,'craft','m230524_000001_entry_type_icons','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','80e1254b-1d87-4b7e-96b2-3a8bbcac8076'),(12,'craft','m230524_000002_entry_type_colors','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','679266fe-0c08-4945-a642-18d4709596c2'),(13,'craft','m230524_220029_global_entry_types','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','4a678367-1bb0-4ff1-a503-bf3286335386'),(14,'craft','m230531_123004_add_entry_type_show_status_field','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','230ef591-2dda-40b4-95cd-7311d0747470'),(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','cff9f1cf-ac7c-45fe-9b61-0a54c71c3185'),(16,'craft','m230616_173810_kill_field_groups','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','002df41c-50a2-4233-bcd1-28852a94c90e'),(17,'craft','m230616_183820_remove_field_name_limit','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','d851b80d-1314-44ff-969b-f623ed8a443f'),(18,'craft','m230617_070415_entrify_matrix_blocks','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','4370d44f-72fe-4661-b358-dd03f0ce44cf'),(19,'craft','m230710_162700_element_activity','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','0f33a2e4-2367-417f-b9a2-ad3a95219073'),(20,'craft','m230820_162023_fix_cache_id_type','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','918b8a6f-e693-4926-87a4-c4bd87860557'),(21,'craft','m230826_094050_fix_session_id_type','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','306d84a6-916e-4a32-8a8f-bd3030b39e43'),(22,'craft','m230904_190356_address_fields','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','6605a211-3c1d-4db4-9795-971d938202af'),(23,'craft','m230928_144045_add_subpath_to_volumes','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','ecc176c0-8de2-4f30-ae86-c1ada2a12f43'),(24,'craft','m231013_185640_changedfields_amend_primary_key','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','c9fb61be-592a-4396-b808-a8af32f0fff6'),(25,'craft','m231213_030600_element_bulk_ops','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','22cce1ca-3dec-47f6-a8b0-9f0a14509ad8'),(26,'craft','m240129_150719_sites_language_amend_length','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','550e2344-cab7-4a45-8989-c3a0f1dba071'),(27,'craft','m240206_035135_convert_json_columns','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','422f718a-a4a0-45d9-b509-d734c27b8687'),(28,'craft','m240207_182452_address_line_3','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','142f6161-614c-4e6b-a094-6ad74621dc75'),(29,'craft','m240302_212719_solo_preview_targets','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','590e8778-4707-4fa2-97ed-6badaee41ce9'),(30,'craft','m240619_091352_add_auth_2fa_timestamp','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','ffc6ee5b-7970-47b9-a582-011274fcdecd'),(31,'craft','m240723_214330_drop_bulkop_fk','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','1e1ee19a-4965-46f0-8416-8916846538fd'),(32,'craft','m240731_053543_soft_delete_fields','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','e3c504b5-ee5b-4afd-b2a4-522a0b6e9848'),(33,'craft','m240805_154041_sso_identities','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','bc57d580-d362-42c1-b0ee-661b00f98185'),(34,'craft','m240926_202248_track_entries_deleted_with_section','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','935c1325-199f-498b-afe8-57be09622063'),(35,'craft','m241120_190905_user_affiliated_sites','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','dde47297-ba14-4143-a262-6a1408edf6f3'),(36,'craft','m241125_122914_add_viewUsers_permission','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','b7dbd62f-1cca-4775-9aed-209cbc0cdbbc'),(37,'craft','m250119_135304_entry_type_overrides','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','1a73ec5c-f678-456e-831f-c58fd4e54cdc'),(38,'craft','m250206_135036_search_index_queue','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','5ed56e91-f92a-47cc-9fcd-89f38a2b0740'),(39,'craft','m250207_172349_bulkop_events','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','fbcf89fc-125f-42a1-a22f-6b7bb69e67ca'),(40,'craft','m250315_131608_unlimited_authors','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','02c139a6-682b-4ce0-b9f8-b45e0f45a1a5'),(41,'craft','m250403_171253_static_statuses','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','1eee3525-7fe5-4fad-bf6a-638b8fa7184c'),(42,'craft','m250512_164202_asset_mime_types','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','6a21ded8-9175-45fe-a6be-26f7c606ec39'),(43,'craft','m250522_090843_add_deleteEntriesForSite_and_deletePeerEntriesForSite_permissions','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','b53bc383-fedb-4906-b64e-8c92c4163cd9'),(44,'craft','m250531_183058_content_blocks','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','7c4aa7d2-bb37-457c-a962-5b5b0b1e9791'),(45,'craft','m250623_105031_entry_type_descriptions','2025-08-27 01:52:16','2025-08-27 01:52:16','2025-08-27 01:52:16','185d5bfd-9169-442f-ae2e-93b6d909672c'),(46,'plugin:google-maps','Install','2025-08-29 02:50:03','2025-08-29 02:50:03','2025-08-29 02:50:03','5a6eb4a2-93df-4388-9be9-c6504e95fc4f'),(47,'plugin:google-maps','m210914_223501_add_subfields','2025-08-29 02:50:03','2025-08-29 02:50:03','2025-08-29 02:50:03','c63d6227-8e8c-49f5-90f5-e1887c2eea86'),(48,'plugin:google-maps','m210914_223502_populate_subfields','2025-08-29 02:50:03','2025-08-29 02:50:03','2025-08-29 02:50:03','f1588865-2c18-49f3-be64-5de5c3e6181e'),(49,'plugin:google-maps','m211111_212501_announcements_v4_1','2025-08-29 02:50:03','2025-08-29 02:50:03','2025-08-29 02:50:03','16818e5c-6ce4-4d02-9452-d496790cb558'),(50,'plugin:google-maps','m221125_125701_update_subfield_config','2025-08-29 02:50:03','2025-08-29 02:50:03','2025-08-29 02:50:03','52fefc11-6cad-4960-8660-8a9c81172fe2'),(51,'plugin:google-maps','m240320_131520_add_more_subfields','2025-08-29 02:50:03','2025-08-29 02:50:03','2025-08-29 02:50:03','3d525e04-5e12-49d7-b1de-d70a6ff6849d'),(52,'plugin:google-maps','m240530_122024_multisite_support','2025-08-29 02:50:03','2025-08-29 02:50:03','2025-08-29 02:50:03','bb3f0b51-5d35-4632-b8a5-6b88604fab60');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `plugins` VALUES (1,'google-maps','5.1.6','4.6.0','2025-08-29 02:50:03','2025-08-29 02:50:03','2025-08-29 02:50:03','de60ebba-5ce1-440d-a279-067c24bbfb9e');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES ('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.defaultPlacement','\"end\"'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.cardThumbAlignment','\"end\"'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elementCondition','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.autocapitalize','true'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.autocomplete','false'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.autocorrect','true'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.class','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.dateAdded','\"2025-08-30T01:33:24+00:00\"'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.disabled','false'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.elementCondition','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.id','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.includeInCards','false'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.inputType','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.instructions','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.label','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.max','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.min','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.name','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.orientation','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.placeholder','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.providesThumbs','false'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.readonly','false'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.requirable','false'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.size','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.step','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.tip','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.title','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\TitleField\"'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.uid','\"fdb72ffa-b710-4a5c-9dd7-090155fbdcc6\"'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.userCondition','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.warning','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.elements.0.width','100'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.name','\"Content\"'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.uid','\"ec1ec6d1-a6c6-4ae7-ab14-13c81d77c640\"'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.fieldLayouts.24788bcc-ece8-4ed4-b4a9-4330ef55cd37.tabs.0.userCondition','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.handle','\"category\"'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.name','\"Category\"'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.siteSettings.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.hasUrls','true'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.siteSettings.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.template','\"category/_category.twig\"'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.siteSettings.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.uriFormat','\"category/{slug}\"'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.structure.maxLevels','null'),('categoryGroups.fc73028f-e956-417d-a9cb-27cf6b5d2777.structure.uid','\"311f262d-d194-4371-a27b-721fa57982c1\"'),('dateModified','1756528872'),('email.fromEmail','\"info@giftsaround.com\"'),('email.fromName','\"Gifts Around\"'),('email.replyToEmail','\"info@giftsaround.com\"'),('email.template','\"\"'),('email.transportSettings.host','\"smtp.zoho.com\"'),('email.transportSettings.password','\"OwlLawn0407!\"'),('email.transportSettings.port','\"465\"'),('email.transportSettings.useAuthentication','\"1\"'),('email.transportSettings.username','\"info@giftsaround.com\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Smtp\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.color','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.description','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.cardThumbAlignment','\"end\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elementCondition','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.autocapitalize','true'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.autocomplete','false'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.autocorrect','true'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.class','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.dateAdded','\"2025-08-29T03:09:43+00:00\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.disabled','false'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.elementCondition','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.id','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.includeInCards','false'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.inputType','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.instructions','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.label','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.max','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.min','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.name','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.orientation','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.placeholder','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.providesThumbs','false'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.readonly','false'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.required','true'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.size','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.step','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.tip','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.title','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.uid','\"76fcb0b5-620e-4508-8975-ff69f718b211\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.userCondition','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.warning','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.0.width','100'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.dateAdded','\"2025-08-29T03:15:47+00:00\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.editCondition','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.elementCondition','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.fieldUid','\"21d5b2e7-055d-41a3-8842-86406bf86748\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.handle','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.includeInCards','false'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.instructions','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.label','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.providesThumbs','false'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.required','false'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.tip','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.uid','\"dce02115-1f00-4201-b877-527c57df8c3f\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.userCondition','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.warning','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.1.width','100'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.dateAdded','\"2025-08-29T03:15:47+00:00\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.editCondition','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.elementCondition','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.fieldUid','\"a955ad2a-a4f5-4a2d-ad4a-d844e4d15140\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.handle','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.includeInCards','false'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.instructions','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.label','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.providesThumbs','false'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.required','false'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.tip','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.uid','\"1631a573-2528-4ea7-9b03-26da53cde2de\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.userCondition','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.warning','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.elements.2.width','100'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.name','\"Content\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.uid','\"e9dd146c-92c1-4819-845e-e9a371e1f1ba\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.fieldLayouts.f4ae60e4-3042-44f1-a5c9-de232d6376fa.tabs.0.userCondition','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.handle','\"monthlySpecial\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.hasTitleField','true'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.icon','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.name','\"Monthly Special\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.showSlugField','true'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.showStatusField','true'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.slugTranslationKeyFormat','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.slugTranslationMethod','\"site\"'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.titleFormat','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.titleTranslationKeyFormat','null'),('entryTypes.998d77d7-e6eb-4b75-842f-ae8280fba567.titleTranslationMethod','\"site\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.color','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.description','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.cardThumbAlignment','\"end\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elementCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.autocapitalize','true'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.autocomplete','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.autocorrect','true'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.class','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.dateAdded','\"2025-08-29T01:28:18+00:00\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.disabled','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.elementCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.id','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.includeInCards','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.inputType','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.instructions','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.label','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.max','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.min','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.name','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.orientation','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.placeholder','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.providesThumbs','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.readonly','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.required','true'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.size','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.step','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.tip','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.title','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.uid','\"cc37d22a-3bb3-4fcb-8b7b-2cee8691d5c6\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.userCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.warning','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.0.width','100'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.dateAdded','\"2025-08-30T01:38:51+00:00\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.editCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.elementCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.fieldUid','\"abca8568-b497-484e-b4d3-5fe77d0d18dd\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.handle','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.includeInCards','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.instructions','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.label','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.providesThumbs','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.required','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.tip','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.uid','\"1a1e0f44-450f-4411-ac10-d5c3c676a549\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.userCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.warning','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.1.width','100'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.dateAdded','\"2025-08-29T01:35:31+00:00\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.editCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.elementCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.fieldUid','\"1681a684-620d-404c-a918-6af20caa8b8b\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.handle','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.includeInCards','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.instructions','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.label','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.providesThumbs','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.required','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.tip','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.uid','\"b0b232e8-582d-4134-866c-0df5c8676231\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.userCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.warning','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.2.width','100'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.dateAdded','\"2025-08-29T01:35:31+00:00\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.editCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.elementCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.fieldUid','\"937faf23-8b1b-469b-9235-401505a750f2\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.handle','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.includeInCards','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.instructions','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.label','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.providesThumbs','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.required','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.tip','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.uid','\"064e31eb-3259-47e6-ad42-baa6e07c6bc0\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.userCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.warning','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.3.width','100'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.dateAdded','\"2025-08-29T01:35:31+00:00\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.editCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.elementCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.fieldUid','\"bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.handle','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.includeInCards','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.instructions','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.label','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.providesThumbs','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.required','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.tip','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.uid','\"4a71ac0d-c816-4eb2-b03c-3084d1f01fbe\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.userCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.warning','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.4.width','100'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.dateAdded','\"2025-08-29T01:35:31+00:00\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.editCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.elementCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.fieldUid','\"90c4ffa5-83bb-4af6-8837-6ad5bf1c323c\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.handle','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.includeInCards','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.instructions','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.label','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.providesThumbs','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.required','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.tip','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.uid','\"cb834a18-7534-4ad0-824f-2fef5b3fcfca\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.userCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.warning','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.5.width','100'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.dateAdded','\"2025-08-29T01:35:31+00:00\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.editCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.elementCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.fieldUid','\"b441d323-0b33-4f14-95c6-153d91a1674d\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.handle','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.includeInCards','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.instructions','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.label','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.providesThumbs','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.required','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.tip','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.uid','\"458ec52d-1155-45bd-a853-39bf9d61d8d8\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.userCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.warning','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.6.width','100'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.dateAdded','\"2025-08-29T03:15:52+00:00\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.editCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.elementCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.fieldUid','\"1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.handle','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.includeInCards','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.instructions','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.label','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.providesThumbs','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.required','false'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.tip','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.uid','\"081ff5c0-c59f-4323-abaf-289ab43b6295\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.userCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.warning','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.elements.7.width','100'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.name','\"Content\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.uid','\"d46d188c-2f64-44c8-8aaa-c0ef97964401\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.fieldLayouts.12f8c6de-4ca2-4da7-b1cb-827f4e01968d.tabs.0.userCondition','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.handle','\"business\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.hasTitleField','true'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.icon','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.name','\"Business\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.showSlugField','true'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.showStatusField','true'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.slugTranslationKeyFormat','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.slugTranslationMethod','\"site\"'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.titleFormat','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.titleTranslationKeyFormat','null'),('entryTypes.9d21a74f-c6b5-434c-8ed2-c75251a61c26.titleTranslationMethod','\"site\"'),('fields.1681a684-620d-404c-a918-6af20caa8b8b.columnSuffix','null'),('fields.1681a684-620d-404c-a918-6af20caa8b8b.handle','\"businessEmail\"'),('fields.1681a684-620d-404c-a918-6af20caa8b8b.instructions','null'),('fields.1681a684-620d-404c-a918-6af20caa8b8b.name','\"Business Email\"'),('fields.1681a684-620d-404c-a918-6af20caa8b8b.searchable','false'),('fields.1681a684-620d-404c-a918-6af20caa8b8b.settings.placeholder','null'),('fields.1681a684-620d-404c-a918-6af20caa8b8b.translationKeyFormat','null'),('fields.1681a684-620d-404c-a918-6af20caa8b8b.translationMethod','\"none\"'),('fields.1681a684-620d-404c-a918-6af20caa8b8b.type','\"craft\\\\fields\\\\Email\"'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.columnSuffix','null'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.handle','\"businessSpecials\"'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.instructions','null'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.name','\"Business Specials\"'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.searchable','false'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.settings.createButtonLabel','null'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.settings.defaultIndexViewMode','\"cards\"'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.settings.enableVersioning','false'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.settings.entryTypes.0.__assoc__.0.0','\"uid\"'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.settings.entryTypes.0.__assoc__.0.1','\"998d77d7-e6eb-4b75-842f-ae8280fba567\"'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.settings.entryTypes.0.__assoc__.1.0','\"group\"'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.settings.entryTypes.0.__assoc__.1.1','\"General\"'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.settings.includeTableView','false'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.settings.maxEntries','null'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.settings.minEntries','null'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.settings.pageSize','50'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.settings.propagationKeyFormat','null'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.settings.propagationMethod','\"all\"'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.settings.showCardsInGrid','false'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.settings.viewMode','\"cards\"'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.translationKeyFormat','null'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.translationMethod','\"site\"'),('fields.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb.type','\"craft\\\\fields\\\\Matrix\"'),('fields.21d5b2e7-055d-41a3-8842-86406bf86748.columnSuffix','null'),('fields.21d5b2e7-055d-41a3-8842-86406bf86748.handle','\"oneSpecial\"'),('fields.21d5b2e7-055d-41a3-8842-86406bf86748.instructions','null'),('fields.21d5b2e7-055d-41a3-8842-86406bf86748.name','\"One Special (same each month)\"'),('fields.21d5b2e7-055d-41a3-8842-86406bf86748.searchable','false'),('fields.21d5b2e7-055d-41a3-8842-86406bf86748.settings.byteLimit','null'),('fields.21d5b2e7-055d-41a3-8842-86406bf86748.settings.charLimit','null'),('fields.21d5b2e7-055d-41a3-8842-86406bf86748.settings.code','false'),('fields.21d5b2e7-055d-41a3-8842-86406bf86748.settings.initialRows','4'),('fields.21d5b2e7-055d-41a3-8842-86406bf86748.settings.multiline','false'),('fields.21d5b2e7-055d-41a3-8842-86406bf86748.settings.placeholder','null'),('fields.21d5b2e7-055d-41a3-8842-86406bf86748.settings.uiMode','\"normal\"'),('fields.21d5b2e7-055d-41a3-8842-86406bf86748.translationKeyFormat','null'),('fields.21d5b2e7-055d-41a3-8842-86406bf86748.translationMethod','\"none\"'),('fields.21d5b2e7-055d-41a3-8842-86406bf86748.type','\"craft\\\\fields\\\\PlainText\"'),('fields.90c4ffa5-83bb-4af6-8837-6ad5bf1c323c.columnSuffix','null'),('fields.90c4ffa5-83bb-4af6-8837-6ad5bf1c323c.handle','\"businessPhone\"'),('fields.90c4ffa5-83bb-4af6-8837-6ad5bf1c323c.instructions','null'),('fields.90c4ffa5-83bb-4af6-8837-6ad5bf1c323c.name','\"Business Phone\"'),('fields.90c4ffa5-83bb-4af6-8837-6ad5bf1c323c.searchable','false'),('fields.90c4ffa5-83bb-4af6-8837-6ad5bf1c323c.settings.fullGraphqlData','true'),('fields.90c4ffa5-83bb-4af6-8837-6ad5bf1c323c.settings.maxLength','255'),('fields.90c4ffa5-83bb-4af6-8837-6ad5bf1c323c.settings.showLabelField','false'),('fields.90c4ffa5-83bb-4af6-8837-6ad5bf1c323c.settings.types.0','\"tel\"'),('fields.90c4ffa5-83bb-4af6-8837-6ad5bf1c323c.translationKeyFormat','null'),('fields.90c4ffa5-83bb-4af6-8837-6ad5bf1c323c.translationMethod','\"none\"'),('fields.90c4ffa5-83bb-4af6-8837-6ad5bf1c323c.type','\"craft\\\\fields\\\\Link\"'),('fields.937faf23-8b1b-469b-9235-401505a750f2.columnSuffix','null'),('fields.937faf23-8b1b-469b-9235-401505a750f2.handle','\"businessAddress\"'),('fields.937faf23-8b1b-469b-9235-401505a750f2.instructions','null'),('fields.937faf23-8b1b-469b-9235-401505a750f2.name','\"Business Address\"'),('fields.937faf23-8b1b-469b-9235-401505a750f2.searchable','false'),('fields.937faf23-8b1b-469b-9235-401505a750f2.settings.maxAddresses','null'),('fields.937faf23-8b1b-469b-9235-401505a750f2.settings.minAddresses','null'),('fields.937faf23-8b1b-469b-9235-401505a750f2.settings.viewMode','\"cards\"'),('fields.937faf23-8b1b-469b-9235-401505a750f2.translationKeyFormat','null'),('fields.937faf23-8b1b-469b-9235-401505a750f2.translationMethod','\"site\"'),('fields.937faf23-8b1b-469b-9235-401505a750f2.type','\"craft\\\\fields\\\\Addresses\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.columnSuffix','null'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.handle','\"multipleSpecials\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.instructions','null'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.name','\"Multiple Specials\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.searchable','false'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.addRowLabel','\"Add a row\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.0.0','\"col14\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.0.1.__assoc__.0.0','\"heading\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.0.1.__assoc__.0.1','\"Month\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.0.1.__assoc__.1.0','\"handle\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.0.1.__assoc__.1.1','\"month\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.0.1.__assoc__.2.0','\"width\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.0.1.__assoc__.2.1','\"\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.0.1.__assoc__.3.0','\"type\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.0.1.__assoc__.3.1','\"singleline\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.1.0','\"col15\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.1.1.__assoc__.0.0','\"heading\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.1.1.__assoc__.0.1','\"Special\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.1.1.__assoc__.1.0','\"handle\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.1.1.__assoc__.1.1','\"special\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.1.1.__assoc__.2.0','\"width\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.1.1.__assoc__.2.1','\"\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.1.1.__assoc__.3.0','\"type\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.columns.__assoc__.1.1.__assoc__.3.1','\"singleline\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.0.__assoc__.0.0','\"col14\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.0.__assoc__.0.1','\"January\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.0.__assoc__.1.0','\"col15\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.0.__assoc__.1.1','\"\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.1.__assoc__.0.0','\"col14\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.1.__assoc__.0.1','\"February\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.1.__assoc__.1.0','\"col15\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.1.__assoc__.1.1','\"\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.10.__assoc__.0.0','\"col14\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.10.__assoc__.0.1','\"November\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.10.__assoc__.1.0','\"col15\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.10.__assoc__.1.1','\"\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.11.__assoc__.0.0','\"col14\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.11.__assoc__.0.1','\"December\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.11.__assoc__.1.0','\"col15\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.11.__assoc__.1.1','\"\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.2.__assoc__.0.0','\"col14\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.2.__assoc__.0.1','\"March\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.2.__assoc__.1.0','\"col15\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.2.__assoc__.1.1','\"\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.3.__assoc__.0.0','\"col14\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.3.__assoc__.0.1','\"April\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.3.__assoc__.1.0','\"col15\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.3.__assoc__.1.1','\"\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.4.__assoc__.0.0','\"col14\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.4.__assoc__.0.1','\"May\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.4.__assoc__.1.0','\"col15\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.4.__assoc__.1.1','\"\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.5.__assoc__.0.0','\"col14\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.5.__assoc__.0.1','\"June\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.5.__assoc__.1.0','\"col15\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.5.__assoc__.1.1','\"\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.6.__assoc__.0.0','\"col14\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.6.__assoc__.0.1','\"July\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.6.__assoc__.1.0','\"col15\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.6.__assoc__.1.1','\"\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.7.__assoc__.0.0','\"col14\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.7.__assoc__.0.1','\"August\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.7.__assoc__.1.0','\"col15\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.7.__assoc__.1.1','\"\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.8.__assoc__.0.0','\"col14\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.8.__assoc__.0.1','\"September\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.8.__assoc__.1.0','\"col15\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.8.__assoc__.1.1','\"\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.9.__assoc__.0.0','\"col14\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.9.__assoc__.0.1','\"October\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.9.__assoc__.1.0','\"col15\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.defaults.9.__assoc__.1.1','\"\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.maxRows','null'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.minRows','null'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.settings.staticRows','true'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.translationKeyFormat','null'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.translationMethod','\"none\"'),('fields.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140.type','\"craft\\\\fields\\\\Table\"'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.columnSuffix','null'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.handle','\"category\"'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.instructions','null'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.name','\"Category\"'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.searchable','false'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.settings.allowSelfRelations','false'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.settings.branchLimit','null'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.settings.defaultPlacement','\"end\"'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.settings.maintainHierarchy','false'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.settings.maxRelations','null'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.settings.minRelations','null'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.settings.selectionLabel','null'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.settings.showCardsInGrid','false'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.settings.showSearchInput','true'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.settings.showSiteMenu','false'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.settings.source','\"group:fc73028f-e956-417d-a9cb-27cf6b5d2777\"'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.settings.targetSiteId','null'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.settings.validateRelatedElements','false'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.settings.viewMode','\"list\"'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.translationKeyFormat','null'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.translationMethod','\"none\"'),('fields.abca8568-b497-484e-b4d3-5fe77d0d18dd.type','\"craft\\\\fields\\\\Categories\"'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.columnSuffix','null'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.handle','\"businessWebsite\"'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.instructions','null'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.name','\"Business Website\"'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.searchable','false'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.settings.fullGraphqlData','true'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.settings.maxLength','255'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.settings.showLabelField','false'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.settings.types.0','\"url\"'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.settings.typeSettings.__assoc__.0.0','\"url\"'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.settings.typeSettings.__assoc__.0.1.__assoc__.0.0','\"allowRootRelativeUrls\"'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.settings.typeSettings.__assoc__.0.1.__assoc__.0.1','\"\"'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.settings.typeSettings.__assoc__.0.1.__assoc__.1.0','\"allowAnchors\"'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.settings.typeSettings.__assoc__.0.1.__assoc__.1.1','\"\"'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.settings.typeSettings.__assoc__.0.1.__assoc__.2.0','\"allowCustomSchemes\"'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.settings.typeSettings.__assoc__.0.1.__assoc__.2.1','\"\"'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.translationKeyFormat','null'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.translationMethod','\"none\"'),('fields.b441d323-0b33-4f14-95c6-153d91a1674d.type','\"craft\\\\fields\\\\Link\"'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.columnSuffix','null'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.handle','\"businessImages\"'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.instructions','null'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.name','\"Business Images\"'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.searchable','false'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.allowedKinds','null'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.allowSelfRelations','false'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.allowSubfolders','false'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.allowUploads','true'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.branchLimit','null'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.defaultPlacement','\"end\"'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.defaultUploadLocationSource','\"volume:56699230-c9fb-4962-9d9b-36f4224b5a07\"'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.defaultUploadLocationSubpath','\"business\"'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.maintainHierarchy','false'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.maxRelations','null'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.minRelations','null'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.previewMode','\"full\"'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.restrictedDefaultUploadSubpath','null'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.restrictedLocationSource','\"volume:56699230-c9fb-4962-9d9b-36f4224b5a07\"'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.restrictedLocationSubpath','null'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.restrictFiles','false'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.restrictLocation','false'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.selectionLabel','null'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.showCardsInGrid','false'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.showSearchInput','true'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.showSiteMenu','true'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.showUnpermittedFiles','false'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.showUnpermittedVolumes','false'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.sources','\"*\"'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.targetSiteId','null'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.validateRelatedElements','false'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.settings.viewMode','\"list\"'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.translationKeyFormat','null'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.translationMethod','\"none\"'),('fields.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3.type','\"craft\\\\fields\\\\Assets\"'),('fs.uploads.hasUrls','true'),('fs.uploads.name','\"Uploads\"'),('fs.uploads.settings.path','\"@webroot/uploads\"'),('fs.uploads.type','\"craft\\\\fs\\\\Local\"'),('fs.uploads.url','\"@web/uploads\"'),('meta.__names__.1681a684-620d-404c-a918-6af20caa8b8b','\"Business Email\"'),('meta.__names__.1bbcf789-77a3-45b6-b5c3-3e7b2f518bcb','\"Business Specials\"'),('meta.__names__.21d5b2e7-055d-41a3-8842-86406bf86748','\"One Special (same each month)\"'),('meta.__names__.366a00bd-3f69-477a-8c1d-d922ec7aed18','\"Business Listing\"'),('meta.__names__.56699230-c9fb-4962-9d9b-36f4224b5a07','\"Business\"'),('meta.__names__.90c4ffa5-83bb-4af6-8837-6ad5bf1c323c','\"Business Phone\"'),('meta.__names__.937faf23-8b1b-469b-9235-401505a750f2','\"Business Address\"'),('meta.__names__.998d77d7-e6eb-4b75-842f-ae8280fba567','\"Monthly Special\"'),('meta.__names__.9d21a74f-c6b5-434c-8ed2-c75251a61c26','\"Business\"'),('meta.__names__.a955ad2a-a4f5-4a2d-ad4a-d844e4d15140','\"Multiple Specials\"'),('meta.__names__.abca8568-b497-484e-b4d3-5fe77d0d18dd','\"Category\"'),('meta.__names__.b441d323-0b33-4f14-95c6-153d91a1674d','\"Business Website\"'),('meta.__names__.bb7cd503-f6ff-480a-b797-4ddb4f3ac9a3','\"Business Images\"'),('meta.__names__.c06bf154-ba2d-40f9-9acc-9b0eb650ed25','\"Gifts Around\"'),('meta.__names__.c7d677fc-5281-4cac-9550-ba58ae4ed0c7','\"Business\"'),('meta.__names__.fc73028f-e956-417d-a9cb-27cf6b5d2777','\"Category\"'),('meta.__names__.fce21e2d-42e7-4672-8d05-682879197a37','\"Nick Test\"'),('plugins.google-maps.edition','\"standard\"'),('plugins.google-maps.enabled','true'),('plugins.google-maps.licenseKey','\"MUWOVOC3IV3R42EB0V9YMBTI\"'),('plugins.google-maps.schemaVersion','\"4.6.0\"'),('plugins.google-maps.settings.browserKey','\"AIzaSyAchsNJLwZZgezhcNislYfzAY27i9o2T2I\"'),('plugins.google-maps.settings.enableJsLogging','true'),('plugins.google-maps.settings.fieldControlSize','27'),('plugins.google-maps.settings.geolocationService','null'),('plugins.google-maps.settings.ipstackApiAccessKey','null'),('plugins.google-maps.settings.maxmindLicenseKey','null'),('plugins.google-maps.settings.maxmindService','null'),('plugins.google-maps.settings.maxmindUserId','null'),('plugins.google-maps.settings.minifyJsFiles','false'),('plugins.google-maps.settings.serverKey','\"AIzaSyA6NNxXQS7HoEWQwYNTN6CV1OkBUNV2yDM\"'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.defaultPlacement','\"end\"'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.enableVersioning','true'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.entryTypes.0.uid','\"9d21a74f-c6b5-434c-8ed2-c75251a61c26\"'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.handle','\"businessListing\"'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.maxAuthors','1'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.name','\"Business Listing\"'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.propagationMethod','\"all\"'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.siteSettings.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.enabledByDefault','true'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.siteSettings.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.hasUrls','true'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.siteSettings.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.template','\"business/index.twig\"'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.siteSettings.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.uriFormat','\"business\"'),('sections.366a00bd-3f69-477a-8c1d-d922ec7aed18.type','\"single\"'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.defaultPlacement','\"end\"'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.enableVersioning','true'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.entryTypes.0.uid','\"9d21a74f-c6b5-434c-8ed2-c75251a61c26\"'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.handle','\"business\"'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.maxAuthors','1'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.name','\"Business\"'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.propagationMethod','\"all\"'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.siteSettings.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.enabledByDefault','true'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.siteSettings.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.hasUrls','true'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.siteSettings.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.template','\"business/_entry.twig\"'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.siteSettings.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.uriFormat','\"business/{slug}\"'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.structure.maxLevels','null'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.structure.uid','\"4ec2f590-21b1-41e8-827d-f5da5ecae990\"'),('sections.c7d677fc-5281-4cac-9550-ba58ae4ed0c7.type','\"structure\"'),('siteGroups.fce21e2d-42e7-4672-8d05-682879197a37.name','\"Nick Test\"'),('sites.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.enabled','true'),('sites.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.handle','\"default\"'),('sites.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.hasUrls','true'),('sites.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.language','\"en\"'),('sites.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.name','\"Gifts Around\"'),('sites.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.primary','true'),('sites.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.siteGroup','\"fce21e2d-42e7-4672-8d05-682879197a37\"'),('sites.c06bf154-ba2d-40f9-9acc-9b0eb650ed25.sortOrder','1'),('system.edition','\"pro\"'),('system.live','true'),('system.name','\"Gifts Around\"'),('system.retryDuration','null'),('system.schemaVersion','\"5.8.0.3\"'),('system.timeZone','\"America/New_York\"'),('users.allowPublicRegistration','true'),('users.deactivateByDefault','false'),('users.defaultGroup','\"\"'),('users.photoSubpath','null'),('users.photoVolumeUid','\"56699230-c9fb-4962-9d9b-36f4224b5a07\"'),('users.require2fa','false'),('users.requireEmailVerification','true'),('users.validateOnPublicRegistration','false'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.altTranslationKeyFormat','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.altTranslationMethod','\"none\"'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.cardThumbAlignment','\"end\"'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elementCondition','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.autocapitalize','true'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.autocomplete','false'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.autocorrect','true'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.class','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.dateAdded','\"2025-08-29T01:36:43+00:00\"'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.disabled','false'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.elementCondition','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.id','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.includeInCards','false'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.inputType','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.instructions','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.label','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.max','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.min','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.name','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.orientation','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.placeholder','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.providesThumbs','false'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.readonly','false'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.requirable','false'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.size','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.step','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.tip','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.title','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.uid','\"c3c168f4-14fb-4d22-9f89-ce6eb5b459d2\"'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.userCondition','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.warning','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.elements.0.width','100'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.name','\"Content\"'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.uid','\"d9c173c2-b7cf-442b-b899-51d82ad30990\"'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fieldLayouts.8f2c97e0-7ee4-483c-9d4f-108e15699bc8.tabs.0.userCondition','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.fs','\"uploads\"'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.handle','\"business\"'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.name','\"Business\"'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.sortOrder','1'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.subpath','\"\"'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.titleTranslationKeyFormat','null'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.titleTranslationMethod','\"site\"'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.transformFs','\"\"'),('volumes.56699230-c9fb-4962-9d9b-36f4224b5a07.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `relations` VALUES (1,3,4,NULL,5,1,'2025-08-29 01:39:54','2025-08-29 01:39:54','7784ede5-8678-42d5-86a1-b94960bea9c6'),(2,3,7,NULL,5,1,'2025-08-29 01:42:02','2025-08-29 01:42:02','34d3d386-d48c-4d0f-8d00-bd060289ed84'),(3,3,11,NULL,13,1,'2025-08-29 02:16:32','2025-08-29 02:16:32','f311c8a4-afc2-4e7f-97ad-6ad3eaa8055b'),(4,3,14,NULL,13,1,'2025-08-29 02:16:35','2025-08-29 02:16:35','3b493cda-1f09-40d4-b9ba-21bf436c1f5a'),(8,9,4,NULL,22,1,'2025-08-30 01:39:24','2025-08-30 01:39:24','f328f64f-38a8-4029-8b2d-a65f49c811fb'),(9,9,28,NULL,22,1,'2025-08-30 01:39:24','2025-08-30 01:39:24','cc5f78dd-14fc-40c9-a7e6-8df6435c29e8'),(10,3,28,NULL,5,1,'2025-08-30 01:39:24','2025-08-30 01:39:24','95ded6ed-7907-41cf-94e5-ac94cdfce7e8');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES (1,4,1,1,''),(2,6,1,1,NULL),(3,9,1,1,NULL),(4,11,1,1,''),(5,12,1,1,NULL),(6,4,1,2,'Applied “Draft 1”'),(7,27,1,1,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' fultonchain gmail com '),(1,'firstname',0,1,' joey '),(1,'fullname',0,1,' joey baloney '),(1,'lastname',0,1,' baloney '),(1,'slug',0,1,''),(1,'username',0,1,' fultonchain '),(2,'slug',0,1,' temp rrzbddfbtlpllkfzyjebtjblouovdgptntto '),(2,'title',0,1,''),(3,'slug',0,1,' temp ivrtaxscgacdrqbrqixavqisyiitsgyvdnvm '),(3,'title',0,1,''),(4,'slug',0,1,' drug farm '),(4,'title',0,1,' drug farm '),(5,'alt',0,1,''),(5,'extension',0,1,' jpg '),(5,'filename',0,1,' dandy jpg '),(5,'kind',0,1,' image '),(5,'slug',0,1,''),(5,'title',0,1,' dandy '),(6,'addressline1',0,1,' 1166 chrisler ave '),(6,'addressline2',0,1,''),(6,'addressline3',0,1,''),(6,'administrativearea',0,1,' ny '),(6,'countrycode',0,1,' us '),(6,'dependentlocality',0,1,''),(6,'fullname',0,1,''),(6,'locality',0,1,' schenectady '),(6,'organization',0,1,''),(6,'organizationtaxid',0,1,''),(6,'postalcode',0,1,' 12303 '),(6,'slug',0,1,' temp qwqushrkpopwjchalbvappxrshvvyoxpafif '),(6,'sortingcode',0,1,''),(6,'title',0,1,' my house '),(9,'slug',0,1,' business listing '),(9,'title',0,1,' business listing '),(11,'slug',0,1,' the other drug farm '),(11,'title',0,1,' the other drug farm '),(12,'addressline1',0,1,' 69 green st '),(12,'addressline2',0,1,''),(12,'addressline3',0,1,''),(12,'administrativearea',0,1,' ny '),(12,'countrycode',0,1,' us '),(12,'dependentlocality',0,1,''),(12,'fullname',0,1,''),(12,'locality',0,1,' new york '),(12,'organization',0,1,''),(12,'organizationtaxid',0,1,''),(12,'postalcode',0,1,' 10012 '),(12,'slug',0,1,' temp qxeldaxhkkivhtbycqzdxdyuhltttbpytxga '),(12,'sortingcode',0,1,''),(12,'title',0,1,' the other drug farm '),(13,'alt',0,1,''),(13,'extension',0,1,' jpg '),(13,'filename',0,1,' img 0575 jpg '),(13,'kind',0,1,' image '),(13,'slug',0,1,''),(13,'title',0,1,' img 0575 '),(17,'slug',0,1,' temp vdkrofkkdfpglshhcsfhtuebxmixpdijsywk '),(17,'title',0,1,''),(22,'slug',0,1,' health beauty '),(22,'title',0,1,' health beauty '),(23,'slug',0,1,' retail '),(23,'title',0,1,' retail '),(24,'slug',0,1,' entertainment '),(24,'title',0,1,' entertainment '),(25,'slug',0,1,' services '),(25,'title',0,1,' services '),(26,'slug',0,1,' food beverage '),(26,'title',0,1,' food beverage '),(27,'slug',0,1,' drug specials '),(27,'title',0,1,' drug specials ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindexqueue`
--

LOCK TABLES `searchindexqueue` WRITE;
/*!40000 ALTER TABLE `searchindexqueue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `searchindexqueue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindexqueue_fields`
--

LOCK TABLES `searchindexqueue_fields` WRITE;
/*!40000 ALTER TABLE `searchindexqueue_fields` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `searchindexqueue_fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,1,'Business','business','structure',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2025-08-29 01:35:52','2025-08-29 01:35:52',NULL,'c7d677fc-5281-4cac-9550-ba58ae4ed0c7'),(2,NULL,'Business Listing','businessListing','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2025-08-29 01:44:29','2025-08-29 01:45:09',NULL,'366a00bd-3f69-477a-8c1d-d922ec7aed18');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_entrytypes` VALUES (1,1,1,NULL,NULL,NULL),(2,1,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'business/{slug}','business/_entry.twig',1,'2025-08-29 01:35:52','2025-08-29 01:35:52','30c4956a-076d-4da0-908f-4cd5a8c83d33'),(2,2,1,1,'business','business/index.twig',1,'2025-08-29 01:44:29','2025-08-29 01:44:29','e1dcf489-f38d-4907-a38f-4f06e8dd54e2');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'Nick Test','2025-08-27 01:52:15','2025-08-27 01:52:15',NULL,'fce21e2d-42e7-4672-8d05-682879197a37');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'1','Gifts Around','default','en',1,'$PRIMARY_SITE_URL',1,'2025-08-27 01:52:15','2025-08-30 00:52:27',NULL,'c06bf154-ba2d-40f9-9acc-9b0eb650ed25');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sso_identities`
--

LOCK TABLES `sso_identities` WRITE;
/*!40000 ALTER TABLE `sso_identities` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sso_identities` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structureelements` VALUES (1,1,NULL,1,1,10,0,'2025-08-29 01:36:01','2025-08-29 02:14:05','5ea32203-ba7d-4c6a-a17b-b36663a6d178'),(2,1,2,1,2,3,1,'2025-08-29 01:36:01','2025-08-29 01:36:01','bf413a57-d933-4187-8c3b-872763a7a3d5'),(3,1,3,1,4,5,1,'2025-08-29 01:38:39','2025-08-29 01:38:39','dc4f240d-f1ee-4dab-8ea1-5c2e0b879d78'),(4,1,4,1,6,7,1,'2025-08-29 01:39:21','2025-08-29 01:39:21','46a14f85-35f0-4908-90c1-b1fd42f70967'),(5,1,11,1,8,9,1,'2025-08-29 02:14:05','2025-08-29 02:14:05','2d770018-eb13-41bc-a429-488a378b8cfe'),(6,2,NULL,6,1,12,0,'2025-08-30 01:34:47','2025-08-30 01:35:49','a8b7dacf-847b-40fc-970b-4278fe730710'),(7,2,22,6,2,3,1,'2025-08-30 01:34:47','2025-08-30 01:34:47','e343052a-e008-4d6a-8078-1d8d0c0fa0a3'),(8,2,23,6,4,5,1,'2025-08-30 01:35:12','2025-08-30 01:35:12','c36bf0e2-0e1d-4d4b-8a71-e679202311b1'),(9,2,24,6,6,7,1,'2025-08-30 01:35:26','2025-08-30 01:35:26','dc83eb72-d3b9-4ec0-aa59-b49fecb68e24'),(10,2,25,6,8,9,1,'2025-08-30 01:35:37','2025-08-30 01:35:37','cdfb5c91-ee4b-491f-ac1d-f73eeabffe9e'),(11,2,26,6,10,11,1,'2025-08-30 01:35:49','2025-08-30 01:35:49','08fcd9f8-425d-468b-a632-c5dbff1a973d');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structures` VALUES (1,NULL,'2025-08-29 01:35:52','2025-08-29 01:35:52',NULL,'4ec2f590-21b1-41e8-827d-f5da5ecae990'),(2,NULL,'2025-08-30 01:34:42','2025-08-30 01:34:42',NULL,'311f262d-d194-4371-a27b-721fa57982c1');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tokens` VALUES (1,'TksXwG6FhEQJYKesXz772YjCFRH5i50b','[\"preview\\/preview\",{\"elementType\":\"craft\\\\elements\\\\Entry\",\"canonicalId\":4,\"siteId\":1,\"draftId\":null,\"revisionId\":null,\"userId\":1}]',NULL,NULL,'2025-08-30 03:29:28','2025-08-29 03:29:28','2025-08-29 03:29:28','4e1a0b0a-43f1-4be6-919c-29a056715be3'),(2,'VOa4FYKQs0L8DR5ySnyL3hK-CLxHTH4b','[\"preview\\/preview\",{\"elementType\":\"craft\\\\elements\\\\Entry\",\"canonicalId\":4,\"siteId\":1,\"draftId\":null,\"revisionId\":null,\"userId\":1}]',NULL,NULL,'2025-08-30 03:31:53','2025-08-29 03:31:53','2025-08-29 03:31:53','2b15a953-5a86-4c5d-a90e-9489aa415961');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\": \"en\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,NULL,NULL,1,0,0,0,1,'fultonchain','Joey Baloney','Joey','Baloney','fultonchain@gmail.com','$2y$13$ScdbI.aW56B9b0mjJyJjJe3C7N3VrDlowFdtiPTFwFfZShtHumFQW','2025-09-02 23:19:20',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2025-08-27 01:52:16','2025-08-27 01:52:16','2025-09-02 23:19:20');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES (1,NULL,NULL,'Temporary Uploads',NULL,'2025-08-29 01:33:27','2025-08-29 01:33:27','46a343db-14e5-4cb3-b805-ba4ca1430725'),(2,1,NULL,'user_1','user_1/','2025-08-29 01:33:27','2025-08-29 01:33:27','9c140509-675d-4eb6-8506-70ac9c6cd56e'),(3,NULL,1,'Business','','2025-08-29 01:38:12','2025-08-29 01:38:12','1372a7a6-6dc9-46ec-a6a3-c93204600ae2');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES (1,2,'Business','business','uploads','','','','site',NULL,'none',NULL,1,'2025-08-29 01:38:12','2025-08-29 01:38:12',NULL,'56699230-c9fb-4962-9d9b-36f4224b5a07');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2025-08-27 01:55:00','2025-08-27 01:55:00','fdddaae3-366b-48c9-9c4f-551fcd470b3e'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2025-08-27 01:55:00','2025-08-27 01:55:00','6dd2e49a-422c-4cfa-8f80-2e1987b1d0d7'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2025-08-27 01:55:00','2025-08-27 01:55:00','0a8d5f3c-4d29-4d0d-b93e-2436b887ae9f'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2025-08-27 01:55:00','2025-08-27 01:55:00','f0fc0f08-5c1b-4dc7-91c6-c6042464b003');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-02 20:22:55
